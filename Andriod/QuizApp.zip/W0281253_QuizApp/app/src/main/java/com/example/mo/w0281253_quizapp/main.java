package com.example.mo.w0281253_quizapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.content.Intent;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.widget.TextView;
import java.io.*;
import java.util.*;


public class main extends AppCompatActivity {

    /*******************VARIABLE DECLARATIONS*************************/
    TextView passUsername;
    ArrayList<String> SYMBOL =  new ArrayList<>();
    ArrayList<String> QUESTIONS = new ArrayList<>();
    ArrayList<String> tempAnswes = new ArrayList<>();
    ArrayList<String> CloneSYMBOL = new ArrayList<>();
    ArrayList<Integer> numCheck = new ArrayList<Integer>();
    Map<String,String> QA = new HashMap<>();
    Random randNum = new Random();
    TextView question;
    Button answer1,answer2,answer3,answer4,exit;
    int currentQuestion=0;
    int loopCount=1;
    int correctCount=0;
    int wrongCount=0;
    String rightAnswer,checkVal,name;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Bundle extras = getIntent().getExtras();

        if(extras != null){
            name = extras.getString("KEY");// GET THE USER NAME FROM INTENT
        }

        /*******************CALL ONLOAD METHOD*************************/
        onLoad();

        /****************CALL LOADQUESTION METHOD*************************/
        loadQuestion();



        /*******************ON CLICK LISTENERS FOR BUTTONS*************************/
        answer1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                checkVal = answer1.getText().toString();
                Execute(); // EXECUTE CALL
            }

        });

        answer2.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                checkVal = answer2.getText().toString();
                Execute();// EXECUTE CALL

            }
        });

        answer3.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                checkVal = answer3.getText().toString();
                Execute();// EXECUTE CALL
            }
        });

        answer4.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                checkVal = answer4.getText().toString();
                Execute();// EXECUTE CALL

            }
        });

        exit.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                Exit(); //EXIT CALL
            }
        });
    }//end of on create

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    /************************ONLOAD METHOD IMPLEMENTATION*********************/
    protected void onLoad()
    {
        /*HANDLE ACTIVITY ELEMENTS*/
        passUsername = (TextView)findViewById(R.id.editTextWelcome);
        question = (TextView)findViewById(R.id.textViewQuestion);
        answer1 = (Button)findViewById(R.id.btnOption1);
        answer2 = (Button)findViewById(R.id.btnOption2);
        answer3 = (Button)findViewById(R.id.btnOption3);
        answer4 = (Button)findViewById(R.id.btnOption4);
        exit = (Button)findViewById(R.id.btnQuit);

        String currentText = passUsername.getText().toString();
        String name;

        Bundle extras = getIntent().getExtras();
        if(extras !=null)
        {
            name = extras.getString("KEY");
            passUsername.setText(currentText + " " + name); //DISPLAY NAME ON TOP OF ACTIVITY
        }
      InputStream is = this.getResources().openRawResource(R.raw.information);//ADD FILE AS RESOURCE

        try
        {
            BufferedReader br = new BufferedReader(new InputStreamReader(is));// TO READ FILE
            String line;

            while((line=br.readLine()) !=null)
            {
                String [] values = line.split(","); // SPLIT LINE READ AND PLACE IN VALUES[]
                SYMBOL.add(values[0]);//PLACE FIRST ELEMENT IN SYMBOL
                QUESTIONS.add(values[1]);// PLACE LAST ELEMENT IN QUESTIONS

            }
        }
        catch (Exception e)
        {
            Log.w("Error:","Error Reading File");
        }

        for(int i =0; i< SYMBOL.size();i++)
        {
            //LOOP THROUGH AND SET THE KEY, VALUE PAIRS FOR THE HASHMAP QA
            QA.put(QUESTIONS.get(i),SYMBOL.get(i));
        }


        Collections.shuffle(QUESTIONS); //SHUFFLE QUESTIONS ARRAYLIST

    }
    /************************LOADQUESTION METHOD IMPLEMENTATION*********************/
    protected void loadQuestion()
    {

        question.setText(QUESTIONS.get(currentQuestion));//DISPLAY QUESTION
        String KEY = QUESTIONS.get(currentQuestion); //  ASSIGN THE QUESTION TO KEY
        rightAnswer =QA.get(KEY); // GET THE RIGHT ANSWER TO QUESTION FORM HASHMAP
        int removeAnswer =SYMBOL.indexOf(rightAnswer);  // GET THE INDEX OF THE RIGHT ANSWER
        CloneSYMBOL = (ArrayList<String>) SYMBOL.clone(); // CLONE THE SYMBOL ARRAYLIST
        CloneSYMBOL.remove(removeAnswer);// REMOVE THE RIGHT ANSWER FORM THE CLONED ARRAYLIST

        tempAnswes.add(rightAnswer); // ADD THE RIGHT ANSWER TO ARRAYLIST HOLDING POSSIBLE ANSWERS
        fillTempAnswers(); // CALL FILL TEMP ANSWERS ARRAY LIST

        Collections.shuffle(tempAnswes); // SHUFFLE THE ANSWERS ARRAYLIST

        /*ASSIGN THE ANSWERS TO THE FOUR ANSWERS CHOICES*/
        answer1.setText(tempAnswes.get(0));
        answer2.setText(tempAnswes.get(1));
        answer3.setText(tempAnswes.get(2));
        answer4.setText(tempAnswes.get(3));

    }

    /************************CHECKANSWER METHOD IMPLEMENTATION*********************/
    protected void checkAnswer(String x)
    {

        if(x.equalsIgnoreCase(rightAnswer)) //IF STRING PASSED EQUALS RIGHT ANSWER
        {
            correctCount +=1; // ADD 1 TO CORRECT COUNT
        }
        else
        {
            wrongCount +=1; //ADD 1 TO WRONG COUNT
        }
    }

    /************************CLEAR METHOD IMPLEMENTATION*********************/
    protected void clear()
    {
        question.setText("");
        answer1.setText("");
        answer2.setText("");
        answer3.setText("");
        answer4.setText("");
        CloneSYMBOL.clear();
        tempAnswes.clear();
        numCheck.clear();
    }

    /************************EXECUTE METHOD IMPLEMENTATION*********************/
    protected void Execute()
    {
       if(currentQuestion==9) // IF LAST QUESTION
        {
            Exit(); // CALL EXIT;
        }
        else
       {
           checkAnswer(checkVal); // CALL CHECKANSWER
           clear(); // CALL CLEAR
           currentQuestion++; // ADD TO CURRENT QUESTION FOR LOAD QUESTION TO MOVE TO NEXT QUESTION
           loadQuestion(); // CALL LAODQUESTION FOR THE NEXT QUESTION
       }

    }


    protected void fillTempAnswers()
    {


        while (loopCount!=4)// NEED 3 OTHER RANDOM ANSWERS LOOP COUNT =1
        {
            int answerToGet = randNum.nextInt((8));//GET RANDOM NUMBER FORM 0-8[ARRAY LIST ZERO BASED]
            if(!numCheck.contains(answerToGet)) // IF ARRAY LIST NUM CHECK DOES NOT CONTAIN RANDOM NUMBER
            {
                numCheck.add(answerToGet); // ADD THE NUMCHEK ARRAY LIST
                loopCount +=1;// ADD 1 TO LOOP COUNT
                String temp = CloneSYMBOL.get(answerToGet); //GET A VALUE FROM THE CLONED ARRAY LIST
                tempAnswes.add(temp); // ADD TO ANSWERS ARRAY
            }
        }
            loopCount =1; //RESET LOOP COUNT TO 1
        }

    /************************EXIT METHOD IMPLEMENTATION*********************/
    protected void Exit()
    {
        /*INTENT TO RESULTS PAGE*/
        checkAnswer(checkVal); // CHECK LAST QUESTION
        Intent endIntent = new Intent(main.this, result.class);
        Bundle extras = new Bundle();
        extras.putString("KEY", name);//Optional parameters
        extras.putInt("score", correctCount);
        endIntent.putExtras(extras);
        startActivity(endIntent);
    }
    }
