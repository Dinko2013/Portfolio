package com.examples.youtubeapidemo;

import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import android.util.Log;

public class DBAdapter {
	public static final String KEY_ROWID = "_id";
	public static final String KEY_LINK = "link";
	public static final String KEY_NAME ="name";
	public static final String KEY_RATING ="rating";
	public static final String TAG = "DBAdapter";
	
	private static final String DATABASE_NAME = "MyDB";
	private static final String DATABASE_TABLE = "Videos";
	private static final int DATABASE_VERSION = 3;
	
	private static final String DATABASE_CREATE =
		"create table Videos("
				+ "_id integer primary key autoincrement,"
				+ "link text not null,"
				+ "name text not null,"
				+ "rating text not null);";

	private static final String DATABASE_POPULATE_1 =
			"INSERT INTO " + DATABASE_TABLE
					+ " (link, name,rating) "
					+ "VALUES "
					+ "('fis-9Zqu2Ro', 'Batman V Superman','4');";

	private static final String DATABASE_POPULATE_2 =
			"INSERT INTO " + DATABASE_TABLE
					+ " (link, name,rating) "
					+ "VALUES "
					+ "('uVdV-lxRPFo', 'Civil_War','5');";

	private static final String DATABASE_POPULATE_3 =
			"INSERT INTO " + DATABASE_TABLE
					+ " (link, name,rating) "
					+ "VALUES "
					+ "('FyKWUTwSYAs', 'DeadPool',4);";
	
	private final Context context;
	private DatabaseHelper DBHelper;
	private SQLiteDatabase db;
	
	public DBAdapter(Context ctx)
	{
		this.context = ctx;
		DBHelper = new DatabaseHelper(context);	
	}
	
	private static class DatabaseHelper extends SQLiteOpenHelper
	{
		DatabaseHelper(Context context)
		{
			super(context,DATABASE_NAME,null,DATABASE_VERSION);
		}
		
		public void onCreate(SQLiteDatabase db)
		{
			try{
				db.execSQL(DATABASE_CREATE);
				db.execSQL(DATABASE_POPULATE_1);
				db.execSQL(DATABASE_POPULATE_2);
				db.execSQL(DATABASE_POPULATE_3);
			}catch(SQLException e){
				e.printStackTrace();
			}		
		}//end method onCreate
		
		public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion)
		{
			Log.w(TAG,"Upgrade database from version " + oldVersion + " to "
			+ newVersion + ", which will destroy all old data");
			db.execSQL("DROP TABLE IF EXISTS contacts");
			onCreate(db);	
		}//end method onUpgrade
	}//end inner class dataBaseHelper
	
	//open the database
	public DBAdapter open() throws SQLException
	{
		db = DBHelper.getWritableDatabase();
		return this;
	}
	
	//close the database
	public void close()
	{
		DBHelper.close();
	}
	
	//insert a contact into the database
	public long insertVideo(String link,String name,String rating)
	{
		ContentValues initialValues = new ContentValues();
		initialValues.put(KEY_LINK,link);
		initialValues.put(KEY_NAME, name);
		initialValues.put(KEY_RATING, rating);
		return db.insert(DATABASE_TABLE, null, initialValues);
	}

	//delete a particular contact
	public boolean deleteVideo(long rowId)
	{
		return db.delete(DATABASE_TABLE,KEY_ROWID + "=" + rowId,null) >0;//0 used for bool return
	}
	
	//retrieve all the contacts
	public Cursor getAllVideos()
	{
		return db.query(DATABASE_TABLE,new String[]{KEY_ROWID,KEY_LINK,
				KEY_NAME,KEY_RATING},null,null,null,null,null);
	}
	
	//retrieve a single contact
	public Cursor getVideo(long rowId) throws SQLException
	{
		Cursor mCursor = db.query(true, DATABASE_TABLE, new String[] {KEY_ROWID,
				KEY_LINK, KEY_NAME,KEY_RATING},KEY_ROWID + "=" + rowId,null,null,null,null,null);
		if(mCursor != null)
		{
			mCursor.moveToFirst();
		}
		return mCursor;
	}
	
	//updates a contact
	public boolean updateVideo(long rowId,String rating)
	{
		ContentValues cval = new ContentValues();
		cval.put(KEY_RATING,rating);
		return db.update(DATABASE_TABLE, cval, KEY_ROWID + "=" + rowId,null) >0;
	}
	
}//end class DBAdapter












