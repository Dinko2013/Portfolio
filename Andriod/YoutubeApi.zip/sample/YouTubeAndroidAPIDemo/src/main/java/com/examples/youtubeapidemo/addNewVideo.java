package com.examples.youtubeapidemo;


import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;


public class addNewVideo extends Activity {


    EditText textLink,textName;
    RatingBar rating;
    Button btnInsert;
    DBAdapter myDB;
    String rateValue;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_video);

        /*********************************Declare activity Objects*****************************/
        textLink = (EditText)findViewById(R.id.editTextLink);
        textName = (EditText)findViewById(R.id.editTextName);
        rating = (RatingBar)findViewById(R.id.ratingBar);
        btnInsert = (Button)findViewById(R.id.BtnAdd);

        /*********************************End of Declarations*****************************/
        openDB(); //open Database Connection
        populateList();// population list view from databse
        videoUpdateItemClick(); // set onclick listener of update
        LongClickDelete();// set onClick listner for delete

        rating.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {

            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {

                rateValue = Double.toString(ratingBar.getRating());
            }
        });
        btnInsert.setOnClickListener(new View.OnClickListener() // Onclick listent of database insert button
        {
            @Override
            public void onClick(View v) {
                String insertLink = textLink.getText().toString();
                String insertName = textName.getText().toString();


                if((!TextUtils.isEmpty(insertLink)) && (!TextUtils.isEmpty(insertName)))
                {
                    myDB.insertVideo(insertLink,insertName,rateValue);
                    Toast.makeText(getBaseContext(), "Insert Successfull!!", Toast.LENGTH_SHORT).show();
                    clear();

                }
                else
                {
                    Toast.makeText(getBaseContext(), "Insert Failed !  ", Toast.LENGTH_SHORT).show();
                }
                populateList();
            }

        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_add_new_video, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void openDB()
    {
        myDB = new DBAdapter(this);
        myDB.open();
    }

    /*Populate list method implementation*/
    private void populateList()
    {
        Cursor cursor  = myDB.getAllVideos();
        String[] fromFielfNames = new String[]{DBAdapter.KEY_ROWID,DBAdapter.KEY_NAME,DBAdapter.KEY_RATING};
        int[] toViewIDs =  new int[]{R.id.textViewId,R.id.txtViewTitle,R.id.txtViewRating};
        SimpleCursorAdapter myCursorAdapter;
        myCursorAdapter = new SimpleCursorAdapter(getBaseContext(),R.layout.videolist_layout,cursor,fromFielfNames,toViewIDs,0);
        ListView myList = (ListView)findViewById(R.id.listViewAdded);
        myList.setAdapter(myCursorAdapter);
    }
    /*Update list method implementation*/
    private void UpdateList(long id)
    {
        Cursor cursor  = myDB.getVideo(id);
        if(cursor.moveToFirst())
        {
            String rate = Double.toString(rating.getRating());
            myDB.updateVideo(id,rate);
        }
        cursor.close();
    }
    /*update item onclick listener implementation*/
    private void videoUpdateItemClick()
    {
        ListView myList = (ListView)findViewById(R.id.listViewAdded);
        myList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                UpdateList(id);
                populateList();
            }
        });

    }
    /*Delete item on Long click listener implementation*/
    private void LongClickDelete()
    {
        ListView myList = (ListView)findViewById(R.id.listViewAdded);
        myList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                myDB.deleteVideo(id);
                populateList();
                return false;
            }
        });
    }

    private void clear()
    {
        textName.setText("");
        textLink.setText("");
        rating.setRating(0);

    }




}
