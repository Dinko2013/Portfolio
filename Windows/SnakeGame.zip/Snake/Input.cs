﻿using System.Collections;
using System.Windows.Forms;

namespace Snake
{
    internal class Input
    {
        /// <summary>
        /// Load list of available Keyboard buttons
        /// </summary>

        private static Hashtable keyTable = new Hashtable();

        /// <summary>
        /// Perform a check to see if a particular button is pressed.
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public static bool KeyPressed(Keys key)
        {
            if (keyTable[key] == null)
            {
                return false;
            }

            return (bool) keyTable[key];
        }

        /// <summary>
        /// Detect if a keyboard button is pressed
        /// </summary>
        /// <param name="key"></param>
        /// <param name="state"></param>
        public static void ChangeState(Keys key, bool state)
        {
            keyTable[key] = state;
        }
    }
}
