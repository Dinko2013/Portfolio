﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Media;
using System.Windows.Forms;

namespace Snake
{
    public partial class Form1 : Form
    {
        private List<Rectangle> Snake = new List<Rectangle>();
        private Rectangle food = new Rectangle();


        static Image image1 = Image.FromFile("UFO2.png");
        static Image image = Image.FromFile("ufo1.png");
        Image wallpaper = Image.FromFile("Wallpaper.jpg");
        Stopwatch stopwatch = Stopwatch.StartNew();
        int level = 1;

        TextureBrush texture = new TextureBrush(image);
        TextureBrush texture2 = new TextureBrush(image1);

        /// <summary>
        /// Default Construtor
        /// Set settings to default
        /// Set game speed and start timer
        /// Start New game
        /// </summary>
        public Form1()
        {
            InitializeComponent();
            new Settings();
            gameTimer.Interval = 1000 / Settings.Speed;
            gameTimer.Tick += UpdateScreen;
            gameTimer.Start();
            StartGame();
           
        }

        /// <summary>
        /// Set settings to default
        /// Create new player object
        /// </summary>
        private void StartGame()
        {
            lblGameOver.Visible = false;
            new Settings();
            Snake.Clear();
            Rectangle head = new Rectangle {X = 10, Y = 5};
            Snake.Add(head);
            lblScore.Text = Settings.Score.ToString();
            label2.Text = level.ToString();
            GenerateFood();
        }

       
        private void GenerateFood()
        {
            int maxXPos = pbCanvas.Size.Width / Settings.Width;
            int maxYPos = pbCanvas.Size.Height / Settings.Height;

            Random random = new Random();
            food = new Rectangle {X = random.Next(0, maxXPos), Y = random.Next(0, maxYPos)};
            SoundPlayer simpleSound = new SoundPlayer("Space entity.Wav");
            simpleSound.Play();

        }


        /// <summary>
        /// Check for Game Over
        /// Check if Enter is pressed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UpdateScreen(object sender, EventArgs e)
        {
            if (Settings.GameOver)
            {
                if (Input.KeyPressed(Keys.Enter))
                {
                    StartGame();
                }
            }
            else
            {
                if (Input.KeyPressed(Keys.Right) && Settings.direction != Direction.Left)
                {
                    Settings.direction = Direction.Right;
                }
                    
                else if (Input.KeyPressed(Keys.Left) && Settings.direction != Direction.Right)
                {
                    Settings.direction = Direction.Left;
                }
                   
                else if (Input.KeyPressed(Keys.Up) && Settings.direction != Direction.Down)
                {
                    Settings.direction = Direction.Up;
                }
                    
                else if (Input.KeyPressed(Keys.Down) && Settings.direction != Direction.Up)
                {
                    Settings.direction = Direction.Down;
                }
                    

                MovePlayer();
            }

            pbCanvas.Invalidate();

        }


        /// <summary>
        /// set space ship of texture
        /// draw Draw Tow ship
        /// draw Food Pickup ship
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pbCanvas_Paint(object sender, PaintEventArgs e)
        {

            GC.Collect();
            Graphics canvas = e.Graphics;

            if (!Settings.GameOver)
            {

                for (int i = 0; i < Snake.Count; i++)
                {

                    
                    canvas.FillRectangle(texture,
                        Snake[i].X * Settings.Width,
                                      Snake[i].Y * Settings.Height,
                                      Settings.Width, Settings.Height);


                    canvas.FillRectangle(texture2,
                        food.X * Settings.Width,
                             food.Y * Settings.Height, Settings.Width, Settings.Height);

                }
            }
            else
            {
                string gameOver = "You Killed the SQUAD! \n final score is: " + Settings.Score + "\nPress Enter to try again";
                lblGameOver.Text = gameOver;
                lblGameOver.Visible = true;
            }
        }



        /// <summary>
        /// Move head
        /// Get maximum X and Y Pos
        /// Detect collission with game borders
        /// Detect collission with Tow Line
        /// Detect collision with pickup piece
        /// Move body
        /// </summary>
        private void MovePlayer()
        {
            for (int i = Snake.Count - 1; i >= 0; i--)
            {
                //Move head
                if (i == 0)
                {
                    switch (Settings.direction)
                    {
                        case Direction.Right:
                            Snake[i].X++;
                            break;
                        case Direction.Left:
                            Snake[i].X--;
                            break;
                        case Direction.Up:
                            Snake[i].Y--;
                            break;
                        case Direction.Down:
                            Snake[i].Y++;
                            break;
                    }


                    //Get maximum X and Y Pos
                    int maxXPos = pbCanvas.Size.Width / Settings.Width;
                    int maxYPos = pbCanvas.Size.Height / Settings.Height;

                    //Detect collission with game borders
                    if (Snake[i].X < 0 || Snake[i].Y < 0
                        || Snake[i].X >= maxXPos || Snake[i].Y >= maxYPos)
                    {
                        Die();
                    }


                    //Detect collission with Tow Line
                    for (int j = 1; j < Snake.Count; j++)
                    {
                        if (Snake[i].X == Snake[j].X &&
                           Snake[i].Y == Snake[j].Y)
                        {
                            Die();
                        }
                    }

                    //Detect collision with pickup piece
                    if (Snake[0].X == food.X && Snake[0].Y == food.Y)
                    {
                        Eat();
                        //if(Snake.Count>10)
                        //{
                        //    Snake.RemoveRange(1, Snake.Count - 1);
                        //}
                    }

                }
                else
                {
                    //Move body
                    Snake[i].X = Snake[i - 1].X;
                    Snake[i].Y = Snake[i - 1].Y;
                }
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            Input.ChangeState(e.KeyCode, true);
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            Input.ChangeState(e.KeyCode, false);
        }

        /// <summary>
        /// check if timer has passes 60 seconds
        /// if yes increase level which increases the point by a factor of level and increases game speed
        /// 
        /// Add Rectangle to body
        /// </summary>
        private void Eat()
        {

            if (stopwatch.ElapsedMilliseconds > 30000)
            {
                stopwatch.Restart();
                Settings.Speed -=5;
                level += 1;
                label2.Text = level.ToString();
                SoundPlayer simpleSound = new SoundPlayer("Power-Up.Wav");
                simpleSound.Play();
                

            }

            //Add Rectangle to body

            Rectangle circle = new Rectangle
            {
                X = Snake[Snake.Count - 1].X,
                Y = Snake[Snake.Count - 1].Y
            };
            Snake.Add(circle);

           
            Settings.Score += Settings.Points * level;
            lblScore.Text = Settings.Score.ToString();

            GenerateFood();
            GC.Collect();
        }

        private void Die()
        {
            Settings.GameOver = true;
            level = 1;
            Settings.Speed = 10;
        }
        /// <summary>
        /// Set Label backgrounds to transparent
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Load(object sender, EventArgs e)
        {
            lblGameOver.Parent = pbCanvas;
            lblScore.Parent = pbCanvas;
            label1.Parent = pbCanvas;
            label2.Parent = pbCanvas;
            label3.Parent = pbCanvas;
            lblGameOver.BackColor = Color.Transparent;
            lblScore.BackColor = Color.Transparent;
            label1.BackColor = Color.Transparent;
            label2.BackColor = Color.Transparent;
            label3.BackColor = Color.Transparent;
            this.WindowState = FormWindowState.Maximized;
            

        }

        private void pbCanvas_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        
    }
}
