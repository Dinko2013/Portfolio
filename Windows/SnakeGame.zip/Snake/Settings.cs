﻿namespace Snake
{
    /// <summary>
    /// Keyboard Input Direction enum Declaration
    /// </summary>
    public enum Direction
    {
        Up,
        Down,
        Left,
        Right
    };

    /// <summary>
    /// Settings public  properties
    /// for game sprit and player
    /// stats
    /// </summary>
    public class Settings
    {
        public static int Width { get; set; }
        public static int Height { get; set; }
        public static int Speed { get; set; }
        public static int Score { get; set; }
        public static int Points { get; set; }
        public static bool GameOver { get; set; }
        public static Direction direction { get; set; }

        /// <summary>
        /// Consustructor class
        /// </summary>
        public Settings()
        {
            Width = 50;
            Height = 50;
            Speed = 16;
            Score = 0;
            Points = 10;
            GameOver = false;
            direction = Direction.Down;
        }
    }


}
