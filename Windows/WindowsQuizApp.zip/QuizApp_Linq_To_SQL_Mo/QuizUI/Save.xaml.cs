﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MahApps.Metro.SimpleChildWindow;
using QuizDataLayer;

namespace QuizUI
{
    /// <summary>
    /// Interaction logic for Save.xaml
    /// </summary>
    public partial class Save : Window
    {
        public string score;
        public string saveName;
        private Controller manager;
        public Save()
        {
            InitializeComponent();
            manager = new Controller();
            
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            score = TakeQuiz.score.ToString();
            textBlockScore.Text = TakeQuiz.score.ToString();

            ExamineesCb.ItemsSource = manager.GetExaminees().Select(E => E.Examinee1).ToList();
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            string examineeName = ExamineesCb.SelectedValue.ToString();
            string saveName = txtSaveName.Text.ToString();
            int Quizscore = Int32.Parse(score);

            Boolean noErrors = manager.InsertQuiz(saveName, Quizscore, examineeName);
            if (noErrors == true)
            {
                MessageBox.Show("Error Saving this Quiz");
            }
            else
            {
                txtSaveName.Clear();
                ExamineesCb.SelectedIndex = 0;
                textBlockScore.Text = "#";
                
                TakeQuiz q = new TakeQuiz();
                this.Close();
                q.Show();
            }
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            TakeQuiz main = new TakeQuiz();
            this.Close();
            main.clearQuizControls();
            main.Show();

        }
    }
}
