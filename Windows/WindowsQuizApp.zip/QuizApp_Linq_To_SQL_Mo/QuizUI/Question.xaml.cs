﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using QuizDataLayer;

namespace QuizUI
{
    /// <summary>
    /// Interaction logic for Question.xaml
    /// </summary>
    public partial class Question : Window
    {
        private Controller manager;
        QuizUI.QuizDataSet quizDataSet;
        QuizUI.QuizDataSetTableAdapters.QuestionTableAdapter quizDataSetQuestionTableAdapter;
        public Question()
        {
            InitializeComponent();
            manager = new Controller();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

             quizDataSet = ((QuizUI.QuizDataSet)(this.FindResource("quizDataSet")));
            // Load data into the table Question. You can modify this code as needed.
            quizDataSetQuestionTableAdapter = new QuizUI.QuizDataSetTableAdapters.QuestionTableAdapter();
            quizDataSetQuestionTableAdapter.Fill(quizDataSet.Question);
            System.Windows.Data.CollectionViewSource questionViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("questionViewSource")));
            questionViewSource.View.MoveCurrentToFirst();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
           
            MainWindow main = new MainWindow();
            this.Close();
            main.execute();
            main.Show();
        }

        private void btnAddQuestion_Click(object sender, RoutedEventArgs e)
        {
            bool ReturnVal = false;
            String question = txtQuestion.Text.ToString();

            try
            {
                ReturnVal = manager.InsertQuestion(question);
            }
            catch (Exception ex)
            {
                ReturnVal = true;
            }

            if (ReturnVal == true)
            {

                MessageBox.Show("New Question Could Not be Added!");
            }
            else
            {
                txtQuestion.Clear();
                this.quizDataSet.Reset();
                this.quizDataSetQuestionTableAdapter.Fill(this.quizDataSet.Question);
            }
        }
    }
    }

