﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using QuizDataLayer;

namespace QuizUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
         private Controller manager;
        public MainWindow()
        {
            InitializeComponent();
            manager = new Controller();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            Examinee ex = new Examinee();
            this.Hide();
            ex.Show();
        }

        private void btnReload_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            Question q = new Question();
            this.Hide();
            q.Show();
        }

        private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            Options o = new Options();
            this.Hide();
            o.Show();

        }

        private void MenuItem_Click_4(object sender, RoutedEventArgs e)
        {
            TakeQuiz t = new TakeQuiz();
            this.Hide();
            t.Show();
        }

        private void MenuItem_Click_5(object sender, RoutedEventArgs e)
        {
            Load l = new Load();
            this.Hide();
            l.Show();
        }

        private void MenuItem_Click_6(object sender, RoutedEventArgs e)
        {
            execute();
        }

        public void execute()
        {
            int QuestionCount = manager.questionsAvailable();
            txtBlockQuestion.Text = QuestionCount.ToString();

            int UseCount = manager.examineesRegistered();
            txtBlockExaminee.Text = UseCount.ToString();

            int QuizCount = manager.SavedQuizes();
            txtblockQuiz.Text = QuizCount.ToString();
        }
    }
}
