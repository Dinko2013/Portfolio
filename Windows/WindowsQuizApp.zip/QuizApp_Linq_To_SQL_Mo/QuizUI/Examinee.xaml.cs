﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using QuizDataLayer;

namespace QuizUI
{
    /// <summary>
    /// Interaction logic for Examinee.xaml
    /// </summary>
    public partial class Examinee : Window
    {
        private Controller manager;
        private string ExamineeName;
        QuizUI.QuizDataSet quizDataSet;
        QuizUI.QuizDataSetTableAdapters.ExamineeTableAdapter quizDataSetExamineeTableAdapter;

        public Examinee()
        {
            InitializeComponent();
            manager = new Controller();
            
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            quizDataSet = ((QuizUI.QuizDataSet)(this.FindResource("quizDataSet")));
            // Load data into the table Examinee. You can modify this code as needed.
            quizDataSetExamineeTableAdapter = new QuizUI.QuizDataSetTableAdapters.ExamineeTableAdapter();
            quizDataSetExamineeTableAdapter.Fill(quizDataSet.Examinee);
            System.Windows.Data.CollectionViewSource examineeViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("examineeViewSource")));
            examineeViewSource.View.MoveCurrentToFirst();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            bool ReturnVal = false;
            ExamineeName = txtExaminee.Text.ToString();

            try
            {
               ReturnVal=manager.InsertExaminee(ExamineeName);
            }
            catch(Exception ex)
            {
                ReturnVal = true;
            }

            if(ReturnVal ==true)
            {

                MessageBox.Show("New Examinee Could Not be Added!");
            }
            else
            {
                txtExaminee.Clear();
                this.quizDataSet.Reset();
                this.quizDataSetExamineeTableAdapter.Fill(this.quizDataSet.Examinee);
            }
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
        //    MainWindow main = new MainWindow();
        //    main.Show();
        //    this.Hide();
            

        }

        private void Window_Closed(object sender, EventArgs e)
        {
            MainWindow main = new MainWindow();
            this.Close();
            main.execute();
            main.Show();

        }
    }
}
