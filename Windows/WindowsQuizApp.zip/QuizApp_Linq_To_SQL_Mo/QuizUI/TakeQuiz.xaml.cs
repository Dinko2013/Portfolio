﻿using QuizDataLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace QuizUI
{
    /// <summary>
    /// Interaction logic for TakeQuiz.xaml
    /// </summary>
    public partial class TakeQuiz : Window
    {
        private Controller manager;
        List<Questions> allQuestions;
        List<Questions> selectedQuestions;
        List<Option> allOptions;
        List<Option> selectedOptions;

        //ints for question number, and score
        int bankcount = 0;
        int counter = 1;
        public static int score = 0;

        //random seed to generate random numbers when needed
        Random rdm = new Random();

        //list of controls to hold radio buttons to assign values in a loop
        List<RadioButton> radioButtons = new List<RadioButton>();
        private object Controls;

        public TakeQuiz()
        {
            InitializeComponent();
            //add radio buttons to group
            radioButtons.Add(Option1);
            radioButtons.Add(Option2);
            radioButtons.Add(Option3);
            radioButtons.Add(Option4);
            manager = new Controller();
        }
        public void clearQuizControls()
        {
            for (int x = 0; x < radioButtons.Count; x++)
            {
                radioButtons[x].Visibility = Visibility.Hidden;
                radioButtons[x].IsChecked = false;
            }
            QuestionTextBlock.Visibility = Visibility.Hidden;
            btnSubmit.Visibility = Visibility.Hidden;
            bankcount = 0;
        }
        public void GenerateQuestionSet()
        {
            allQuestions = manager.GetList();
            selectedQuestions = new List<Questions>();

            for (int x = 0; x < 5; x++)
            {
                if (allQuestions.Count > 0)
                {
                    int index = rdm.Next(0, allQuestions.Count - 1);
                    selectedQuestions.Add(allQuestions[index]);
                    allQuestions.RemoveAt(index);
                }
            }

            QuestionDisplay();

        }
        private void QuestionDisplay()
        {
            //get question from list of questions, assign its value to textbox, then remove from list
            Questions q = selectedQuestions[bankcount];
            QuestionTextBlock.Text = q.txt;
            QuestionTextBlock.Visibility = Visibility.Visible;
            selectedQuestions.RemoveAt(bankcount);

            //get list of all possible options for this question
            allOptions = manager.GetList(q.QuestionId);

            //add correct answer to list, then remove from available options
            selectedOptions = new List<Option>();
            selectedOptions.Add(allOptions.Where(O => O.CorrectAnswer == 1).First());
            allOptions.Remove(allOptions.Where(O => O.CorrectAnswer == 1).First());

            //add three more options to fill out list, removing from master list
            List<Option> tempList1 = new List<Option>();
            tempList1 = manager.otherAnswers(q.QuestionId);
            for (int x = 0; x < tempList1.Count; x++)
            {

                selectedOptions.Add(tempList1[x]);

            }

            //Make a temporary copy of the selected options list.
            //This allows list items to be removed as they are added to radio buttons to prevent duplication
            //without destroying the original list.
            //The original list will be needed later to check if the answer is correct.
            List<Option> tempList = new List<Option>(selectedOptions);

            //up to four radio buttons need to be added
            for (int x = 0; x < 4; x++)
            {
                if (tempList.Count > 0)
                {
                    int i = rdm.Next(0, tempList.Count - 1);
                    radioButtons[x].Content = tempList[i].txt;
                    radioButtons[x].Visibility = Visibility.Visible;
                    tempList.RemoveAt(i);
                }
            }

            textBlockQuestionCount.Text = counter.ToString();
            btnSubmit.Visibility = Visibility.Visible;
            hideInactive();
            bankcount++;
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            RadioButton checkbutton=null;
           foreach(RadioButton button in radioButtons)
            {
                if(button.IsChecked ==true)
                {
                    checkbutton = button;
                }
            }
            if (checkbutton != null)
            {
                Option o = selectedOptions.Where(O => O.txt == checkbutton.Content.ToString()).Single();

                if (o.CorrectAnswer == 1)
                {
                    score++;
                    MessageBox.Show("Correct Answer!", "Correct/Wrong");
                }
                else
                {
                    MessageBox.Show("Wrong Answer", "Correct/Wrong");
                }

                counter++;

                clearQuizControls();

                if (selectedQuestions.Count > 0)
                {
                    QuestionDisplay();
                }
                else
                {
                    MessageBox.Show(("Final Score: " + score + "/" + (counter - 1)), "Done!");

                    Save s = new Save();
                    this.Hide();
                    s.Show();

                }
            }
            else
            {
                MessageBox.Show("Please select an answer before submitting.", "Error!");
            }
        }
        private void hideInactive()
        {
            if (Option1.Content.ToString() == "RadioButton")
            {
                Option1.Visibility = Visibility.Hidden;
            }
            if (Option2.Content.ToString() == "RadioButton")
            {
                Option2.Visibility = Visibility.Hidden;
            }
            if (Option3.Content.ToString() == "RadioButton")
            {
                Option3.Visibility = Visibility.Hidden;
            }
            if (Option4.Content.ToString() == "RadioButton")
            {
                Option4.Visibility = Visibility.Hidden;
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GenerateQuestionSet();
        }

        private void TakeQuiz1_Closed(object sender, EventArgs e)
        {
            MainWindow main = new MainWindow();
            this.Close();
            main.execute();
            main.Show();
        }
    }
}
