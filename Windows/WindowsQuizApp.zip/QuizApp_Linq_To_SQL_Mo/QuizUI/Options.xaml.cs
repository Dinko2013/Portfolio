﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using QuizDataLayer;

namespace QuizUI
{
    /// <summary>
    /// Interaction logic for Options.xaml
    /// </summary>
    public partial class Options : Window
    {
        private Controller manager;
        private string OptionTxt;
        private int rightAnswer;
        private string question;
        QuizUI.QuizDataSet quizDataSet;
        QuizUI.QuizDataSetTableAdapters.OptionTableAdapter quizDataSetOptionTableAdapter;
        public Options()
        {
            InitializeComponent();
            manager = new Controller();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            quizDataSet = ((QuizUI.QuizDataSet)(this.FindResource("quizDataSet")));
            // Load data into the table Option. You can modify this code as needed.
            quizDataSetOptionTableAdapter = new QuizUI.QuizDataSetTableAdapters.OptionTableAdapter();
            quizDataSetOptionTableAdapter.Fill(quizDataSet.Option);
            System.Windows.Data.CollectionViewSource optionViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("optionViewSource")));
            optionViewSource.View.MoveCurrentToFirst();
            LoadComboBox();
        }

        public void LoadComboBox()
        {
            comboBox.ItemsSource = manager.GetList().Select(Q => Q.txt).ToList();
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            if(checkBCorrect.IsChecked== true)
            {
                rightAnswer = 1;
            }
            else
            {
                rightAnswer = 0;
            }
            question = comboBox.SelectedValue.ToString();
            OptionTxt = txtAnswer.Text.ToString();

          bool noError =  manager.InsertOption(OptionTxt, rightAnswer, question);
            if(noError==false)
            {
                MessageBox.Show("Error Inserting this Option");
            }
            else
            {
                txtAnswer.Clear();
                checkBCorrect.IsChecked = false;
                comboBox.SelectedIndex = 0;
                this.quizDataSet.Reset();
                this.quizDataSetOptionTableAdapter.Fill(this.quizDataSet.Option);
            }
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            //this.Close();
            //MainWindow main = new MainWindow();
            //main.Show();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            this.Close();
            MainWindow main = new MainWindow();
            main.execute();
            main.Show();
        }
    }
}
