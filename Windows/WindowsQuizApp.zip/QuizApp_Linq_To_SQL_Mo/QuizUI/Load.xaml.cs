﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using QuizDataLayer;

namespace QuizUI
{
    /// <summary>
    /// Interaction logic for Load.xaml
    /// </summary>
    /// 
    public partial class Load : Window
    {
        private Controller manager;
        QuizS result = new QuizS();
        
        public Load()
        {
            InitializeComponent();
            manager = new Controller();
        }

        private void btnLoad_Click(object sender, RoutedEventArgs e)
        {
            string name = txtSaveName.Text.ToString();
           
            result = manager.LoadSaved(name);
            textBlockQName.Text = result.qname.ToString();
            textBlockEName.Text = result.ename.ToString();
            textBlockScore.Text = result.score.ToString();
            textBlockDate.Text = result.date.ToString();

        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            textBlockQName.Text = "";
            textBlockEName.Text = "";
            textBlockScore.Text ="";
            textBlockDate.Text = "";
            txtSaveName.Text = "";
            result = null;
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            MainWindow main = new MainWindow();
            this.Close();
            main.execute();
            main.Show();
                
        }
    }
}
