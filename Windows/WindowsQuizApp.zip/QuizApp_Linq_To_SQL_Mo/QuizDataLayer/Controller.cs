﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Linq;
namespace QuizDataLayer
{
   public class Controller
    {
        public List<Examinee> examinees = new List<Examinee>();
        public List<Quiz> quizes = new List<Quiz>();
        public List<Questions> question = new List<Questions>();
        public List<Option> options = new List<Option>();


        private class DataHelper : DataContext
        {
            public DataHelper() :
               base("Data Source=(localdb)\\MSSQLLocalDB; Initial Catalog=Quiz; Integrated Security=True"
               + "AttachDbFilename=C:\\UsersMo\\Desktop\\QuizApp_Linq_To_SQL_Mo\\Data\\Quiz.mdf ; Initial Catalog=Quiz; Integrated Security=True")
            { }

            public Table<Examinee> Examinees;
            public Table<Quiz> Quizes;
            public Table<Questions> Questions;
            public Table<Option> Options;
        }

        private DataHelper data;

        public Controller()
        {
            data = new DataHelper();
        }

        public Examinee CheckExaminees(int ExamineeId)
        {
            foreach (Examinee ex in examinees)
            {
                if (ex.ExamineeId == ExamineeId)
                {
                    return ex;
                }
            }
            return null;
        }
        public Boolean InsertQuiz(string Name,int Score,string ExamineeName)
        {
            bool nullError = false;
            int ExamineeId = 0;
            Examinee checkExamieeExist;
            

            
            try
            {
                var query = (from Examinee in data.Examinees.AsEnumerable()
                             where Examinee.Examinee1 == ExamineeName
                             select new { Examinee.ExamineeId}).Single();
                ExamineeId = Convert.ToInt32(query.ExamineeId);
                //checkExamieeExist = CheckExaminees(ExamineeName);
                Quiz insertQuiz = new Quiz();
                insertQuiz.Name = Name;
                insertQuiz.Score = Score;
                insertQuiz.ExamineeId = ExamineeId;
                DateTime da = DateTime.Now;
                insertQuiz.Date = da;

                data.Quizes.InsertOnSubmit(insertQuiz);
                data.SubmitChanges();
            } 
            catch(NullReferenceException ex)
            {
                nullError = true;
                return nullError;
            }
            return nullError;
           
        }

        public bool InsertExaminee(string name)
        {
            bool Error = false;
            try
            {
                Examinee InsertExaminee = new Examinee();
                InsertExaminee.Examinee1 = name;

                data.Examinees.InsertOnSubmit(InsertExaminee);
                data.SubmitChanges();

            }
            catch (Exception e)
            {
                Error = true;
                return Error;

            }
            return Error;
        }
        public bool InsertQuestion(string Question)
        {
            bool Error = false;
            try
            {
                Questions InsertQuestion = new Questions();
                InsertQuestion.txt = Question;

                data.Questions.InsertOnSubmit(InsertQuestion);
                data.SubmitChanges();

            }
            catch (Exception e)
            {
                Error = true;
                return Error;

            }
            return Error;
        }
        public List<Questions> GetList()
        {
            List<Questions> questions = new List<Questions>();

           
                try
                {
                    var query = from Question in data.Questions
                                select Question;
                    questions = query.ToList();
                }
                catch (Exception e)
                {
                    throw e;
                }

            return questions;
        }
        public List<Quiz> GetAllQuizes()
        {
            List<Quiz> q = new List<Quiz>();


            try
            {
                var query = from Quiz in data.Quizes
                            select Quiz;
                q = query.ToList();
            }
            catch (Exception e)
            {
                throw e;
            }

            return q;
        }
        public List<Examinee> GetExaminees()
        {
            List<Examinee> examinees = new List<Examinee>();


            try
            {
                var query = from Examinee in data.Examinees
                            select Examinee;
                examinees = query.ToList();
            }
            catch (Exception e)
            {
                throw e;
            }

            return examinees;
        }

        public List<Option> GetList(int qId)
        {
            List<Option> options = new List<Option>();

                try{
                    var query = from Option in data.Options
                                where Option.QuestionID == qId
                                select Option;
                    options = query.ToList();
                }
                catch (Exception e)
                {
                    throw e;
                }
            

            return options;
        }
        public List<Option> otherAnswers(int qId)
        {
            List<Option> options = new List<Option>();

            try
            {
                var query = from Option in data.Options
                            where Option.QuestionID == qId
                            && Option.CorrectAnswer!=1
                            select Option;
                options = query.ToList();
            }
            catch (Exception e)
            {
                throw e;
            }


            return options;
        }
        public bool InsertOption(String optiontText, int correctAnswer, string Question)
        {
            bool Error = false;
            int ActualQuestionId;

            try
            {
                Option o = new Option();

                var query = (from Questions in data.Questions.AsEnumerable()
                             where Questions.txt == Question
                             select new { Questions.QuestionId }).Single();
                ActualQuestionId = Convert.ToInt32(query.QuestionId);

                o.txt = optiontText;
                o.CorrectAnswer = correctAnswer;
                o.QuestionID = ActualQuestionId;

                data.Options.InsertOnSubmit(o);
                data.SubmitChanges();
            }
            catch (Exception ex)
            {
                Error = true;
                return Error;
            }
            return true;

        }

        public QuizS LoadSaved(string saveName)
        {
            
            QuizS returnObj = new QuizS();

            try
            {
                var query = (from Quiz in data.Quizes.AsEnumerable()
                             where Quiz.Name == saveName
                             select Quiz).Single();

                var query1 = (from Quiz in data.Quizes.AsEnumerable()
                              join Examinee in data.Examinees.AsEnumerable() on 
                              Quiz.ExamineeId equals Examinee.ExamineeId
                              where Quiz.Name ==saveName
                              select new{ Quiz.Name, Quiz.Date, Quiz.Score, Examinee.Examinee1}
                              ).FirstOrDefault();
                returnObj.qname = query1.Name;
                returnObj.ename = query1.Examinee1;
                returnObj.score = query1.Score;
                returnObj.date = query1.Date;

                return returnObj;
            }
            catch(Exception e)
            {
                return null;
            }
        }
        public int questionsAvailable()
        {
            List<Questions> q = GetList();
            int count = q.Count();
            return count;
        }
        public int examineesRegistered()
        {
            List<Examinee> E = GetExaminees();
            int count = E.Count();
            return count;
        }
        public int SavedQuizes()
        {
            List<Quiz> E = GetAllQuizes();
            int count = E.Count();
            return count;
        }
    }
}
