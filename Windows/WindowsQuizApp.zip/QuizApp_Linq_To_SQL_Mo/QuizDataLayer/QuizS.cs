﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuizDataLayer
{
    public class QuizS
    {
        public string qname { get; set; }
        public string ename { get; set; }
        public int score { get; set; }
        public DateTime date { get; set; }
    }
}
