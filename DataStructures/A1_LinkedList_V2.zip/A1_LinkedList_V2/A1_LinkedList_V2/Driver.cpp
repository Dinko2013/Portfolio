#include "stdafx.h"
#include "LinkedList.h"
#include <iostream>
#include <ostream>
#include <conio.h>
#include <regex>
#include <string.h>

using namespace std;

LinkedList list;
void displayControls();
void ResetCombination();
void GenerateCombination();
ostream& operator<< (ostream& output, LinkedList& list);

int main()
{
	//intro text and menu
	cout << "Welcome to Assignment 1 - Linked Lists" << endl;
	cout << "This App will allow you to set, edit and save a combination for a lock." << endl;
	cout << "Enter 'B' to begin, or enter 'C' to see the controls." << endl;

	bool started = false;
	bool quit = false;

	//regex patterns
	regex c("^[Cc]$");
	regex b("^[Bb]$");
	regex q("^[Qq]$");
	regex e("^[Ee]$");
	regex g("^[Gg][ ][0-6]$");
	regex s("^[Ss][ ][0-9][0-9]*$");
	regex d("^[Dd]$");
	regex r("^[Rr]$");

	do {

		string strInput = "";

		getline(cin, strInput);

		//view controls
		if (regex_match(strInput, c)) {
			displayControls();
		}
		//begin or reset lock
		else if (regex_match(strInput, b))
		{
			if (!started)
			{
				started = true;
				GenerateCombination();
			}
			else
			{
				cout << "Input not recognized.To review the controls, enter 'C'" << endl;
			}
		}
		//quit, no save
		else if (regex_match(strInput, q))
		{
			quit = true;
		}
		//quit, save combo to file
		else if (regex_match(strInput, e))
		{
			string fileName;
			cout << "Please enter enter a file name to save your combination." << endl;

			//fileName = list.SaveCombination(fileName);
			cout << fileName;

			_getch();
			quit = true;
		}
		//set current active node
		else if (regex_match(strInput, g))
		{
			char *a = new char[strInput.size() + 1];
			a[strInput.size()] = 0;
			memcpy(a, strInput.c_str(), strInput.size());

			string value = "";
			value += a[2];

			int code = stoi(value);
			list.SetActive(code);

			cout << list;
		}
		//substitute a new value for current active node
		else if (regex_match(strInput, s))
		{
			char *a = new char[strInput.size() + 1];
			a[strInput.size()] = 0;
			memcpy(a, strInput.c_str(), strInput.size());

			string value = "";
			value += a[2];
			value += a[3];

			//convert value to int
			int code = stoi(value);

			//check that code is in valid range
			if (code <= 49)
			{
				list.ReplaceValue(code);
				cout << list;
			}
			else
			{
				cout << "Value must be between 0-49." << endl;
			}
		}
		//set current node value to 0 (delete)
		else if (regex_match(strInput, d))
		{
			list.DeleteValue();

			cout << list;
			//list.displayList();
		}
		else if (regex_match(strInput, r))
		{
			ResetCombination();
		}
		//input not recognized
		else
		{
			cout << "Input not recognized. To review the controls, enter 'C'" << endl;
		}

	} while (!quit);

	return 0;
}

void displayControls()
{
	cout << endl;
	cout << "Q(QUIT) \tThe Q command signifies exit immediately without saving changes." << endl;
	cout << "E(EXIT) \tThe E command signifies exit and saving the combination in the text file passed in as a command \n\t\tline parameter." << endl;
	cout << "G(GOTO) \tThe G command allows you to set the position of the CURRENT working lock value to support the D \n\t\tand S commands.For example, G 4 sets the CURRENT working lock value to the fourth \n\t\tposition in the sequence.The CURRENT working position will be indicated to \n\t\tthe user at all times." << endl << endl;
	cout << "S(SUBSTITUTE) \tThe S command allows you to swap a new value in for an old value.The S is followed by one \n\t\tspace followed by a valid <Value>(0 - 49).Any other variants will be rejected. The \n\t\tS will swap the CURRENT lock value and replace it with the new value.The \n\t\tDirection will be preserved from the current value." << endl << endl;
	cout << "D(DELETE) \tThe D command may be entered to delete the CURRENT working value in the combination. The D will \n\t\tDelete the CURRENT working value and replace it with <Direction>0 (Zero). It will \n\t\tthen re-display the current value of the new combination. The direction \n\t\twill be preserved. For example, a value of R14 would become R0." << endl << endl;
	cout << "R (RESET) \tThe R command resets the combination to all zeroes, preserving the <Directions>. The new blank \n\t\tcode will be displayed and the CURRENT working position will be set to the first \n\t\tnumber in the sequence" << endl << endl;
}

void GenerateCombination()
{
	for (int x = 0; x < 7; x++)
	{
		if (x % 2 == 0) {
			list.Add(0, 'R');
		}
		else
		{
			list.Add(0, 'L');
		}
	}

	list.SetActive(0);
	cout << list;
}

void ResetCombination()
{
	for (int i = 0; i < 7; i++)
	{
		list.SetActive(i);
		list.DeleteValue();
	}

	list.SetActive(0);
	cout << list;
}


ostream& operator<< (ostream& output, LinkedList& list) 
{
	string strOutput = list.DisplayList();
	cout << strOutput;
	return output;
}

