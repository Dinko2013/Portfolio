#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include <string.h>
#include <iostream>

using namespace std;


class LinkedList
{
public:
	struct Node
	{
		char dir;
		int value;//value
		bool active = false;
		struct Node *next;//pointer to next node
	};

	Node *first; // points to first struct in mem
	int active;

	LinkedList() : first(NULL) {}

	virtual ~LinkedList();
	void Add(int num, char direction);
	void DeleteValue();
	void ReplaceValue(int value);
	void SetActive(int num);
	int GetActive();
	string DisplayList();

};
#endif
