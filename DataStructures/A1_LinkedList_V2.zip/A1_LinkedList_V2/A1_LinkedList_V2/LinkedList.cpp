#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <string.h>
#include "LinkedList.h"
#include <sstream> 

using namespace std;

LinkedList::~LinkedList()
{
	Node *node = first;

	while (node != NULL)
	{
		Node *temp = node;

		node = node->next;

		delete temp;
	}
}

void LinkedList::Add(int num, char direction)
{
	Node *node = new Node();
	node->value = num;
	node->dir = direction;

	if (first == NULL)
	{
		first = node;
	}
	else
	{
		Node *currNode = first;
		Node *prevNode = NULL;

		while (currNode != NULL)
		{
			prevNode = currNode;
			currNode = currNode->next;
		}

		if (prevNode != NULL)
		{
			prevNode->next = node;
		}
	}
}

void LinkedList::DeleteValue()
{
	Node *node = first;

	if (node != NULL)
	{
		for (int x = 0; x < active; x++)
		{
			node = node->next;
		}

		node->value = 0;
	}
}

void LinkedList::ReplaceValue(int value)
{
	Node *node = first;

	for (int x = 0; x < active; x++)
	{
		if (node->next)
		{
			node = node->next;
		}
	}

	node->value = value;
}

void LinkedList::SetActive(int num)
{
	active = num;
}

int LinkedList::GetActive()
{
	return active;
}

string LinkedList::DisplayList()
{
	string output = "";

	Node *node; // To move through the list
	node = first; // Move nodePointer to head of list

	for (int x = 0; x < 7; x++)
	{
		if (x == active)
		{
			char aChar = '0' + x;
			output += aChar;
			output += "< ";
		}
		else
		{
			char aChar = '0' + x;
			output += aChar;
			output += "  ";
		}
	}

	output += "\n";

	while (node)// while it points to a node - traverse
	{
		output += node->dir;

		char txt[2] = { NULL, NULL };
		sprintf_s(txt, "%d", node->value);

		//output += node->value;
		output += txt[0];
		output += txt[1];
		output += " ";
		node = node->next;
	}

	output += "\n";

	return output;

}//end method displayList
