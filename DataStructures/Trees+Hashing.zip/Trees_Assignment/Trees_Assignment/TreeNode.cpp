#include <iostream>
#include "TreeNode.h"
using namespace std;

TreeNode::TreeNode()
{	
		left = NULL;
		right = NULL;
		data = "";
		height = 0;
}

TreeNode::TreeNode(string n)
{
	left = NULL;
	right = NULL;
	data = n;
	height = 0;
}
