#include <iostream>
#include <conio.h>
#include <ctime>
#include <time.h>
#include <string>
#include "AutoBalancingTree.h"
#include "Searching.h";
#include "HashTable.h";
#include <fstream>;

using namespace std;

int main()
{
	int SIZE = 51;
	AutoBalancingTree sbbst;
	HashTable* table = new HashTable(51);
	Searching search;
	cout << "Binary Search Tree Auto Balancing\n";
	int testArray[100000];
	string val="";
	char ch;

	clock_t start;
	double sduration;
	double bduration;
	int result1 = 0;
	int result2 = 0;

	/*  Perform tree + Hashing operations  */
	do
	{
		cout << "\nBinary Search Tree  Operations\n";
		cout << "1. Read File to Autobalancing tree " << endl;
		cout << "2. Search Tree" << endl;
		cout << "3. Insert onto Tree" << endl;
		cout << "4. Run Spellcheck with a Tree Structure" << endl;
		cout << "5. Read File in to a Hash Table" << endl;
		cout << "6. Run Spellcheck with a HashTable" << endl;
		cout << "7. Search Comparison" << endl;
		int choice;
		cout << "Enter your Choice: ";
		cin >> choice;
		switch (choice)
		{
		case 3:
			cout << "Enter element to insert: ";
			cin >> val;
			sbbst.insert(val);
			cout << sbbst;
			break;
		case 2:
			cout << "Enter element to search: ";
			cin >> val;
			if (sbbst.search(val))
				cout << val << " found in the tree" << endl;
			else
				cout << val << " not found" << endl;
				cout << sbbst;
			break;
		case 1:
			cout << "Enter Dictionary file name: ";
			cin >> val;
			sbbst.CreateDictionaryFromFile(val);
			cout << sbbst;
			break;
		case 4:
			cout << "Enter file name: ";
			cin >> val;
			sbbst.SpellChecker(val);
			break;
		case 7:
			int num;
			cout << "Filling Array"<<endl;
			search.fillarray(testArray);
			cout << "Done!" << endl;
			cout << "Enter an Integer to run comparison: ";
			cin >> num;
			start = std::clock();
			for (int i = 0; i < 100000; i++)
			{
				result1 = search.seqsearch(testArray, num);
			}
			sduration = (std::clock() - start) / (double)CLOCKS_PER_SEC;
			start =std:: clock();

			for (int i = 0; i < 100000; i++)
			{
				result2 = search.binarysearch(testArray, num);
			}
			
			bduration = (clock() - start) / (double)CLOCKS_PER_SEC;
			cout << "Seqencial Search Duration :" + std::to_string(sduration) << endl;
			cout << "Binary Search Duration :" + std::to_string(bduration) << endl;
			break;
		case 5:
			cout << "Enter Dictionary file name: ";
			cin >> val;
			table=table->loadDictionaryFromFile(val, table);
			cout << "Dictionary loading complete"<<endl;
			table->toString();
			break;
		case 6:
		{
			string word;
			ifstream file("mispelled.txt");

			if (file.is_open())
			{
				try {
					while (getline(file, word, ' '))
					{
						word = table->clearSpecialChars(word);
						word[0] = tolower(word[0]);
						if (!word.empty())
						{
							if (!table->find(word))
								cout << "[" << word << "] ";
							else
							{
								cout << word << " ";
							}
						}

					}
				}
				catch (exception e)
				{
					cout << e.what();
				}
			}
			else
			{
				cout << "could not open mispelled file" << endl;
			}
		}
		default:
			cout << "Wrong Entry \n ";
			break;
		}
		cout << "\nDo you want to continue (Type y or n): ";
		cin >> ch;
	} while (ch == 'Y' || ch == 'y');
	return 0;
}


