#include <iostream>
#include <ctime>
#include "Searching.h"
using namespace std;


void Searching::ShellSort(int num[100000])
{
	int i, j, temp, increment;

	for (increment = 100000 / 2; increment > 0; increment /= 2) {
		for (i = increment; i<100000; i++) {
			temp = num[i];
			for (j = i; j >= increment; j -= increment) {
				if (temp < num[j - increment])
				{
					num[j] = num[j - increment];
				}
				else
				{
					break;
				}
			}
			num[j] = temp;
		}
	}
}
void Searching::fillarray(int numbers[100000])
{
	for (int i = 0; i < 100000; i++)
	{
		numbers[i] = i+1;
	}

}

int Searching::seqsearch(int numbers[100000], int key)
{
	int i;
	for (i = 0; i < 100000; i++)
	{
		if (key == numbers[i])
			return i;
	}
	return -1;
}
int Searching:: binarysearch(int numbers[100000], int key)
{
	int l = 0, u = 100000 - 1;
	int c, mid;
	while (l <= u) {
		mid = (l + u) / 2;
		if (key == numbers[mid]) {
			return mid;
		}
		else if (key < numbers[mid]) {
			u = mid - 1;
		}
		else
			l = mid + 1;
	}
	return -1;
}