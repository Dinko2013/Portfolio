#ifndef _HASHTABLE_H
#define _HASHTABLE_H

#include "iostream"
#include "string.h"
#include "AutoBalancingTree.h"
using namespace std;

class HashTable
{
public:
	int arraySize = 0;

	AutoBalancingTree** hashtable;

	HashTable(int size);
	int hashFunction(string keyString);
	void insert(string keyString, int address);
	bool find(string keyString);
	HashTable* loadDictionaryFromFile(string fileName,HashTable* table);
	string clearSpecialChars(string &text);
	void toString();
};

#endif