#include "AutoBalancingTree.h"
#include "HashTable.h"
#include "TreeNode.h"
#include <string>
#include <fstream>
#include <algorithm>
using namespace std;

HashTable::HashTable(int size)
{
	arraySize = size;
	hashtable = new AutoBalancingTree*[arraySize];

	for (int x = 0; x < arraySize; x++)
	{
		hashtable[x] = NULL;
	}
}

void HashTable::insert(string keyString, int address)
{
	if (hashtable[address] == NULL)
	{
		hashtable[address] = new AutoBalancingTree();
	}

	hashtable[address]->insert(keyString);
}

bool HashTable::find(string keyString)
{
	int index = hashFunction(keyString);

	if (hashtable[index] != NULL)
	{
		return hashtable[index]->search(keyString);
	}
	else
	{
		return false;
	}
}

int HashTable::hashFunction(string keyString)
{
	unsigned int hashVal = 0;
	for (unsigned int i = 0; i < keyString.length(); i++)
		hashVal ^= (hashVal << 5) + (hashVal >> 2) + keyString[i];
	int x = hashVal % arraySize;
	return  x;


	//int i, sum, address;

	//sum = 0;
	//int len = keyString.length();
	//for (i = 0; i < len; i++)
	//	sum += (int)keyString[i]; // cast each character of the string as int to get ascii value

	//							  // the modulus, or remainder, of integer division gives a result between 0 and SIZE-1, perfect for an index
	//address = sum % arraySize;
	//return address;
}
string HashTable::clearSpecialChars(string &text)
{
	const string chars = "\".,!()[]&'<>:/{}_|=+;-#`123456789~\x00";

	auto new_end = std::remove_if(text.begin(), text.end(), [chars](string::value_type c)
	{ return chars.find(c) != string::npos; });
	text.erase(new_end, text.end());
	return text;
}

HashTable* HashTable::loadDictionaryFromFile(string fileName,HashTable* table)
{
	string word;
	ifstream file(fileName);

	if (file.is_open())
	{
		try {
			while (getline(file, word))
			{
				int x = hashFunction(word);
				cout << "WORD: " << word << "\tGenerated Key: " << x<<endl;
				table->insert(word, x);
			}
		}
		catch (exception e)
		{
			cout << e.what();
		}
	}

	return table;
}

void HashTable::toString()
{
	string output = "";

	for (int x = 0; x < arraySize; x++)
	{
		output += "HashTable[";
		output += to_string(x);
		output += "] - \n";

		if (hashtable[x] != NULL)
		{
			cout << endl;
			cout << *hashtable[x]<<endl;
			cout << "---------------------"<<endl;
		}

	}
}
