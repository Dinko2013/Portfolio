#pragma once
#include <iostream>
using namespace std;
class TreeNode

{
public:
	string data;
	int height;
	TreeNode *left;
	TreeNode *right;


	/* Default Constructor */
	TreeNode();

	/* Constructor with String */
	TreeNode(string word);
};

