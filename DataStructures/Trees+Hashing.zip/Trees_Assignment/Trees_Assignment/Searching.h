#pragma once
#include <iostream>
#include <ctime>
using namespace std;

class Searching
{
private:
	int nums[100000];
public:
	void ShellSort(int numbers[100000]);
	void fillarray(int numbers[100000]);
	int seqsearch(int numbers[100000], int key);
	int binarysearch(int numbers[100000], int key);
};
