#include <iostream>
#include <fstream>
#include<sstream>
#include<vector>
#include <algorithm>
#include <iomanip>
#include<string>
#include "AutoBalancingTree.h"

using namespace std;
AutoBalancingTree::AutoBalancingTree()
{
	root = NULL;
}

/* Function to check if tree is empty */
bool AutoBalancingTree:: isEmpty()
{
	return root == NULL;
}

/* Make the tree logically empty */
void AutoBalancingTree ::makeEmpty()
{
	root = NULL;
}

/* Function to insert data */
void AutoBalancingTree:: insert(string data)
{
	root = insert(data, root);
}

/* Function to get height of node */
int AutoBalancingTree:: height(TreeNode *t)
{
	return t == NULL ? -1 : t->height;
}

/* Function to max of left/right node */
int AutoBalancingTree:: max(int lhs, int rhs)
{
	return lhs > rhs ? lhs : rhs;
}

/* Function to insert data recursively */
TreeNode* AutoBalancingTree:: insert(string x, TreeNode *t)
{
	if (t == NULL)
		t = new TreeNode(x);
	else if (x < t->data)
	{
		t->left = insert(x, t->left);
		if (height(t->left) - height(t->right) == 2)
			if (x < t->left->data)
				t = rotateWithLeftChild(t);
			else
				t = doubleRotateWithLeftChild(t);
	}
	else if (x > t->data)
	{
		t->right = insert(x, t->right);
		if (height(t->right) - height(t->left) == 2)
			if (x > t->right->data)
				t = rotateWithRightChild(t);
			else
				t = doubleRotateWithRightChild(t);
	}
	t->height = max(height(t->left), height(t->right)) + 1;
	return t;
}

/* Rotate binary tree node with left child */
TreeNode* AutoBalancingTree:: rotateWithLeftChild(TreeNode* k2)
{
	TreeNode *k1 = k2->left;
	k2->left = k1->right;
	k1->right = k2;
	k2->height = max(height(k2->left), height(k2->right)) + 1;
	k1->height = max(height(k1->left), k2->height) + 1;
	return k1;
}

/* Rotate binary tree node with right child */
TreeNode* AutoBalancingTree:: rotateWithRightChild(TreeNode *k1)
{
	TreeNode *k2 = k1->right;
	k1->right = k2->left;
	k2->left = k1;
	k1->height = max(height(k1->left), height(k1->right)) + 1;
	k2->height = max(height(k2->right), k1->height) + 1;
	return k2;
}

/*
* Double rotate binary tree node: first left child
* with its right child; then node k3 with new left child
*/
TreeNode* AutoBalancingTree::doubleRotateWithLeftChild(TreeNode *k3)
{
	k3->left = rotateWithRightChild(k3->left);
	return rotateWithLeftChild(k3);
}

/*
* Double rotate binary tree node: first right child
* with its left child; then node k1 with new right child
*/
TreeNode* AutoBalancingTree::doubleRotateWithRightChild(TreeNode *k1)
{
	k1->right = rotateWithLeftChild(k1->right);
	return rotateWithRightChild(k1);
}

/* Functions to count number of nodes */
int AutoBalancingTree:: countNodes()
{
	return countNodes(root);
}

int  AutoBalancingTree::countNodes(TreeNode *r)
{
	if (r == NULL)
		return 0;
	else
	{
		int l = 1;
		l += countNodes(r->left);
		l += countNodes(r->right);
		return l;
	}
}

/* Functions to search for an element */
bool AutoBalancingTree::search(string val)
{
	return search(root, val);
}

bool AutoBalancingTree:: search(TreeNode *r, string val)
{
	bool found = false;
	while ((r != NULL) && !found)
	{
		string rval = r->data;

		val[0] = tolower(val[0]);

		if (val < rval)
			r = r->left;
		else if (val > rval)
			r = r->right;
		else
		{
			found = true;
			break;
		}
		found = search(r, val);
	}
	return found;
}

 TreeNode* AutoBalancingTree::CreateDictionaryFromFile(string &fileName)
{
	TreeNode* root = NULL;

	fstream myfile(fileName);

	while (myfile.good()) {
		string line;
		getline(myfile, line);
		string word = line;
		insert(word);
	}
	myfile.close();

	return root;
}
unsigned int AutoBalancingTree::split(string txt, vector<string> strs, char ch)
 {
	 unsigned int pos = txt.find(ch);
	 unsigned int initialPos = 0;
	 strs.clear();

	 // Decompose statement
	 while (pos != string::npos) {
		 strs.push_back(txt.substr(initialPos, pos - initialPos));
		 initialPos = pos + 1;

		 pos = txt.find(ch, initialPos);
	 }

	 // Add the last one
	 strs.push_back(txt.substr(initialPos, std::fmin(pos, txt.size()) - initialPos + 1));

	 return strs.size();
 }
 void AutoBalancingTree::SpellChecker(string &fileName)
 {
	 
	 string s;
	 vector <string>readInWords;
	 fstream myfile(fileName);
	 string line;
	 while (myfile.good()) {
		 getline(myfile, line);
	 }

	 myfile.close();

	 line = clearSpecialChars(line);
	 istringstream iss(line);

	 while (getline(iss, s, ' '))
	 {
		 readInWords.push_back(s);
	 }


	 for (int i = 0; i < readInWords.size(); i++)
	 {
		 bool found = search(root,readInWords.at(i));
		 if (found == false)
		 {
			 cout << endl;
			 cout << readInWords.at(i) << " is spelled incorrectly" << endl;
		 }
	 }
	 
 }
 void AutoBalancingTree::PrintTree(ostream& output, NodePtr &node, int indent)
 {
	 if (node != NULL)
	 {
		 PrintTree(output, node->left,0);

		 output << setw(indent) << node->data << endl;

		 PrintTree(output, node->right,0);
	 }
 }

 string AutoBalancingTree::clearSpecialChars(string &text)
 {
	 const string chars = "\".,!()[]&'<>:/{}_|=+;-#`123456789~\x00";

	 auto new_end = std::remove_if(text.begin(), text.end(),[chars](string::value_type c)
	 { return chars.find(c) != string::npos; });
	 text.erase(new_end, text.end());
	 return text;
 }

 ostream& operator<<(ostream &output, AutoBalancingTree &ast)
 {
	 ast.PrintTree(output, ast.root, 0);

	 return output;
 }