#pragma once
#include <iostream>
#include <vector>
#include "TreeNode.h"


using namespace std;

class AutoBalancingTree:TreeNode
{

	typedef TreeNode* NodePtr;
private:
	TreeNode * root;
public :
	
	AutoBalancingTree();
	bool isEmpty();
	void makeEmpty();
	void insert(string data);
	int height(TreeNode *node);
	int max(int lhs, int rhs);
	int countNodes();
	int countNodes(TreeNode *node);
	bool search(string val);
	bool search(TreeNode *node, string val);
	string clearSpecialChars(string &text);
	TreeNode *insert(string x, TreeNode *node);
	TreeNode *rotateWithLeftChild(TreeNode* node);
	TreeNode *rotateWithRightChild(TreeNode *node);
	TreeNode *doubleRotateWithLeftChild(TreeNode* node);
	TreeNode *doubleRotateWithRightChild(TreeNode *node);
	TreeNode* CreateDictionaryFromFile(string &fileName);
	unsigned int split(string txt, vector<string> strs, char ch);
	void SpellChecker(string &fileName);
	void PrintTree(ostream& output, NodePtr &node, int indent);
	string PrintNode(NodePtr &root);
	friend ostream& operator<<(ostream &output, AutoBalancingTree &abt);

};
