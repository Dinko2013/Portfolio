#include <iostream>
#include "stacknode.h"
#include "stack.h"
#include <deque>

using namespace std;

Stack::Stack() : _top(NULL)
{
}

Stack::~Stack()
{
	/*while (_top != NULL)
	{
		Pop();
	}*/
}
bool Stack::search(deque<int[2]> x, int Position[2] )
{
	
	for (int i = 0; i < x.size(); i++)
	{
		if (x[i] == Position)
		{
			return true;
		}
		else
			return false;
	}
}
myerror_code Stack::Push(int postion[2])
{
	_top = new StackNode(postion[0], postion[1], _top);
	return(success);
}

int* Stack::Peek()
{
	if (_top != NULL)
	{
		return _top->getPostion();
	}
	return NULL;
}

myerror_code Stack::Pop()
{
	if (_top != NULL) {

		StackNode* node = _top;
		_top = _top->getNext();
		delete node;
		return(success);
	}
	else {
		return(underflow);
	}
}

ostream& operator<<(ostream& output, Stack& stack)
{
	StackNode *node = stack._top;

	while (node != NULL)
	{
		cout << node->getPostion() << endl;
		node = node->getNext();
	}

	return output;
}

