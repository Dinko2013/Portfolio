#ifndef _STACKNODE_H
#define _STACKNODE_H
/*STACKNODE CLASS DEFINITION*/
class StackNode
{

private:
	//PRIVATE PROPERTIES
	int postion[2];
	StackNode *_next=NULL;

public:
	//CLASS METHOD/FUNCTION DEFINITIONS
	StackNode();
	StackNode(int x, int y, StackNode* next);
	virtual ~StackNode();
	int * getPostion();
	void setPostion(int myPosition[2]);
	StackNode* getNext();
	void setNext(StackNode *next);
};
#endif

