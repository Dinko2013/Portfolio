#include <iostream>
#include <fstream>
#include "Stack.h"
#include "StackNode.h"
#include "Maze.h"
#include <string>
#include <vector>
using namespace std;


Maze::Maze() // Default Constructor
{
	this->_maze = NULL;
	this->_maze_width = 0;
	this->_maze_height = 0;
	this->_startPosX = 1;
	this->_startPosY = 0;
	this->_endPosX = 0;
	this->_endPosY = 0;
}
Maze::Maze(string filename) // constructor with Arguments
{
	Maze overrideMaze = readInMaze(filename);
	this->_maze = overrideMaze.getMaze();
	this->_maze_width = overrideMaze.getMaze_width();
	this->_maze_height = overrideMaze.getMaze_height();
	this->_startPosX = overrideMaze.getStartPosX();
	this->_startPosY = overrideMaze.getStartPosY();
	this->_endPosX = overrideMaze.getEndPosX();
	this->_endPosY = overrideMaze.getEndPosY();
}
/******************Access and Mutate Methods*****************/
int Maze::getMaze_height()
{
	return _maze_height;
}
int Maze::getMaze_width()
{
	return _maze_width;
}
void Maze::setMaze_height(int num)
{
	_maze_height = num;
}
void Maze::setMaze_width(int num)
{
	_maze_width = num;
}
void Maze::setStartPosX(int num)
{
	_startPosX = num;
}
void Maze::setStartPosY(int num)
{
	_startPosY = num;
}
int Maze::getStartPosX()
{
	return _startPosX;
}
int Maze::getStartPosY()
{
	return _startPosY;
}
void Maze::setEndPosX(int num)
{
	_endPosX = num;
}

void Maze::setEndPosY(int num)
{
	_endPosY = num;
}
int Maze::getEndPosX()
{
	return _endPosX;
}
int Maze::getEndPosY()
{
	return _endPosY;
}
char** Maze::getMaze()
{
	return _maze;
}
void Maze::setMaze(char** maze)
{
	_maze = maze;
}
/**************End of Access and Mutate Methods*****************/

bool HasbeenVisited(vector<Int2> x, Int2 postion);
bool isWALL(char y);


Maze Maze::readInMaze(string filename) 
{
	Maze returnMaze;
	ifstream inStream(filename);
	string readLine;
	if (inStream.fail())
	{
		cout << "Could not find " << endl;

	}
	else
	{
		// get Width and Height of Maze
		_maze_width = getMazeWidth(filename);
		_maze_height = getMazeHeight(filename);


		// Initalize and empty 2 demensional Character Array
		char **tempArray = new char*[_maze_width];
		for (int i = 0; i < _maze_width; ++i)
		{
			tempArray[i] = new char[_maze_height];
		}

		readLine.clear();// reset readLine back to first line of file


		int x = -1; // represents row in [Row][Column]
		
		//read every line in file and build a 2 demensional char array
		while (x <_maze_height)
		{
			getline(inStream, readLine);
			x++;
			for (std::string::size_type i = 0; i < readLine.size(); ++i)
			{
					tempArray[x][i] = readLine[i];
					cout << tempArray[x][i];	
			}
			cout << endl;
		}

		// 
		returnMaze.setMaze_height(_maze_height);
		returnMaze.setMaze_width(_maze_width);
		returnMaze.setStartPosX(1);
		returnMaze.setStartPosY(0);
		returnMaze.setEndPosX(_maze_height - 1);
		returnMaze.setEndPosY(_maze_width-1);
		returnMaze.setMaze(tempArray);

		return returnMaze;
	}
}
Maze:: ~Maze()
{
	
}

// operator override to compare custom struct Int2
bool operator ==(Int2 &value1, Int2 &value2)
{
	if (value1.postion[0] == value2.postion[0] && value1.postion[1] == value2.postion[1])
	{
		return true;
	}
	else
	{
		return false;
	}
}
void Maze::NavigateMaze(Maze* maze)
{
	Stack Path;
	
	vector <Int2> visited;

	
	int oldPosition[2] = {0,0};
	int CurrentPostion[2] = {0,0};
	int EndPosition[2] = {0,0};
	Int2 PostionVisited = { 0,0 };
	Int2 ComparePostion = { 0,0 };
	CurrentPostion[0] = maze->getStartPosX();
	CurrentPostion[1] = maze->getStartPosY();
	EndPosition[0] = maze->getEndPosX();
	EndPosition[1] = maze->getEndPosY();
	//push the start position on the path stack and VisitedStack
	PostionVisited = {oldPosition[0],oldPosition[1]};
	visited.push_back(PostionVisited);
	char ** Grid = maze->getMaze();
	Path.Push(CurrentPostion);
	while (!(CurrentPostion [0]== EndPosition[0] && CurrentPostion[1] == EndPosition[1]))
	{
			
		
		//move Right
		if (!isWALL(Grid[CurrentPostion[0]][CurrentPostion[1] + 1]) && Grid[CurrentPostion[0]][CurrentPostion[1] + 1] == ' ' && CurrentPostion[1] + 1 < maze->_maze_width && !HasbeenVisited(visited, ComparePostion = { CurrentPostion[0],CurrentPostion[1] + 1 }))
		{
			CurrentPostion[1] +=1;
			Path.Push(CurrentPostion);
			visited.push_back(ComparePostion);
			

		}
		//move Up
		else if (!isWALL(Grid[CurrentPostion[0]-1][CurrentPostion[1]]) && Grid[CurrentPostion[0] - 1][CurrentPostion[1]] == ' ' && CurrentPostion[0] - 1 < maze->_maze_height && !HasbeenVisited(visited, ComparePostion = { CurrentPostion[0] - 1,CurrentPostion[1] }))
		{
			CurrentPostion[0] -= 1;
			Path.Push(CurrentPostion);
			visited.push_back(ComparePostion);
		}

		//move down
		else if (!isWALL(Grid[CurrentPostion[0]+1][CurrentPostion[1]]) && Grid[CurrentPostion[0] + 1][CurrentPostion[1]] == ' ' &&CurrentPostion[0] + 1 < maze->_maze_height && !HasbeenVisited(visited, ComparePostion = { CurrentPostion[0] + 1,CurrentPostion[1] }))
		{
			
			CurrentPostion[0] +=1;
			Path.Push(CurrentPostion);
			visited.push_back(ComparePostion);
		}
		//Move left
		else if (!isWALL(Grid[CurrentPostion[0]][CurrentPostion[1] - 1]) && Grid[CurrentPostion[0]][CurrentPostion[1] - 1] == ' ' && CurrentPostion[1] - 1 < maze->_maze_width && !HasbeenVisited(visited, ComparePostion = { CurrentPostion[0],CurrentPostion[1] - 1 }))
		{
			CurrentPostion[1] -=1;
			Path.Push(CurrentPostion);
			visited.push_back(ComparePostion);
		}
		else
		{
			
			Path.Pop();
			int * newTopPostion = Path.Peek();
			CurrentPostion[0] = *newTopPostion;
			++newTopPostion;
			CurrentPostion[1] = *newTopPostion;

		}
	}
	PrintMaze(Grid, Path);
	
}

/*
SOURCE REFERENCED FROM:http://stackoverflow.com/questions/3482064/counting-the-number-of-lines-in-a-text-file
CREDIT:http://stackoverflow.com/users/179910/jerry-coffin
PURPOSE: Number of lines in a text file
*/
int Maze::getMazeHeight(string x)
{
	ifstream inStream(x);
	int number_of_lines = 0;
	char c;
	int i = 0;
	while (inStream.get(c))
		if (c == '\n')
			++number_of_lines;
	return number_of_lines;
}
int Maze::getMazeWidth(string x)
{
	string readLine = "";
	fstream inStream(x);
	getline(inStream, readLine);

	return readLine.length();
}

bool HasbeenVisited(vector<Int2> x, Int2 Position)
{
	int count = 0;
	Int2* data = x.data();
	while (count < x.size())
	{
		if (*data == Position)
		{
			return true;
			break;
		}
		++data;
		count++;
	}
	return false;
}
bool isWALL(char y)
{
	char WALL[] = { '|','+','-' };
	for (int i = 0; i < 3; i++)
	{
		if (WALL[i] == y)
		{
			return true;
		}
	}
		
	return false;
}
void Maze::PrintMaze(char** maze, Stack Path)
{
	cout << endl;
	cout << endl;
	cout << "MAZE PATH:" << endl;
	int noErrors=0;
	int count = 0;
	while (noErrors!=underflow)
	{
		
		int * newTopPostion = Path.Peek();
		if (Path.Peek()==NULL)
		{
			break;
		}
		int x = *newTopPostion;
		++newTopPostion;
		int y = *newTopPostion;
		maze[x][y] = '#';
		noErrors=Path.Pop();
		count++;
	}
	for (int i = 0; i <= this->getMaze_height(); i++)
	{
		for (int j = 0; j < this->getMaze_width(); j++)
		{
			cout << maze[i][j];
		}
		cout << endl;
	}
	
	cout << "Maze Dimentions: " << "Width: " << this->getMaze_width() << " Height: " << this->getMaze_height() << endl;
	cout << endl;
}
