#pragma once
#ifndef _STACK_H
#define _STACK_H
#include <iostream>
#include <deque>
#include "stacknode.h"
using namespace std;
enum myerror_code { success, underflow, overflow };

class Stack
{
private:

	StackNode *_top;

public:
	Stack();
	virtual ~Stack();

	myerror_code Push(int postion[2]);
	int* Peek();
	bool search(deque <int[2]> x, int Position[2]);
	myerror_code Pop();
	friend ostream& operator<<(ostream& output, Stack& stack);
};

#endif

