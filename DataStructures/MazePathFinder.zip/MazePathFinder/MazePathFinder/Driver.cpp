/* Name : Momodou Lamin Keita
Assignment Title: Maze Path-Finder
Due Date: 02/12/2016
*/
#include <iostream>
#include <conio.h>
#include "Stack.h"
#include "StackNode.h"
#include "Maze.h"
#include <string>
#include <regex>
using namespace std;


regex VALIDINPUT("^[1-6]$");


int main()
{	
	Maze* running;
	string sChoice;
	int iChoice;
	bool stop = false;
	do
	{
		bool validInput = false;

		do
		{
			cout << "WELCOME TO ASSIGNMENT2-> THE MAZE PATH-FINDER" << endl;
			cout << "For Maze 1 Press 1" << endl;
			cout << "For Maze 2 Press 2" << endl;
			cout << "For Maze 3 Press 3" << endl;
			cout << "TO EXIT PROGRAM PRESS 4" << endl;
			cin >> sChoice;

			if (regex_match(sChoice, VALIDINPUT))
			{
				validInput = true;
				iChoice = stoi(sChoice);
			}
			else
			{
				validInput = false;
			}
		} while (!validInput);
		
		switch (iChoice)
		{
		case 1:
			running = new Maze("maze1.txt");
			running->NavigateMaze(running);
			break;
		case 2:
			running = new Maze("maze2.txt");
			running->NavigateMaze(running);
			break;
		case 3:
			running = new Maze("maze3.txt");
			running->NavigateMaze(running);
			break;
		case 4:
			stop = true;
			break;
		default:
			cout << "INVALID INPUT" << endl;
		}

	} while (stop==false);
	_getch();

}