#pragma once
#include <iostream>
#include "Stack.h"
#include "StackNode.h"

/* Name : Momodou Lamin Keita
Assignment Title: Maze Path-Finder
Due Date: 02/12/2016
*/

/*MAZE CLASS DEFINITION*/
using namespace std;
/*STRUCT FOR POSTIONS ON MAZE GRID*/
struct Int2 
{
	int postion[2];
};
class Maze
{
protected:
	//PRIVATE PROPERTIES
	int _maze_width;
	int _maze_height;
	int _startPosX;
	int _startPosY;
	int _endPosX;
	int _endPosY;
	char ** _maze;
public:
	//CLASS METHOD/FUNCTION DEFINITIONS
	Maze();
	Maze(string filename);
	int getMaze_height();
	int getMaze_width();
	void setMaze_height(int num);
	void setMaze_width(int num);
	void setStartPosX(int num);
	void setStartPosY(int num);
	int getStartPosX();
	int getStartPosY();
	void setEndPosX(int num);
	void setEndPosY(int num);
	int getEndPosX();
	int getEndPosY();
	void setMaze(char ** maze);
	char** getMaze();
	int getMazeHeight(string x);
	int getMazeWidth(string x);
	Maze readInMaze(string filename);
	virtual ~Maze();
	void NavigateMaze(Maze* maze);
	void PrintMaze(char** maze, Stack Path);
	friend bool operator ==(Int2 &value1, Int2 &value2);
};
