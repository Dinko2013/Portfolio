#include <iostream>
#include "stacknode.h"

using namespace std;

StackNode::StackNode()
{
	this->postion[0] =0;
	this->postion[1] = 1;
	this->setNext(NULL);
}

StackNode::StackNode(int x, int y, StackNode* next)
{
	this->postion[0] = x;
	this->postion[1] = y;
	this->setNext(next);
}

StackNode::~StackNode()
{

}

int* StackNode::getPostion()
{
	return postion;
}

void StackNode::setPostion(int myPosition[2])
{
	myPosition[0] = postion[0];
	myPosition[1] = postion[1];
}

StackNode* StackNode::getNext()
{
	return _next;
}

void StackNode::setNext(StackNode *next)
{
	_next = next;
}
