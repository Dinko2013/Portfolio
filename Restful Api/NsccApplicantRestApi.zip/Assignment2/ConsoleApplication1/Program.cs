﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

using NsccApplication_DataLayer;
namespace ConsoleApplication1
{
    public class Program
    {
        static void Main(string[] args)
        {
            using (var db = new NsccApplicationContext())
            {
               //db.Database.Initialize(true);
                var countries = db.Countries.ToList();
                //var country = new Country();
                //country.CountryCode = "US";
                //country.CountryName = "United States";

                //db.Countries.Add(country);

                //db.SaveChanges();

            }
              

        }
    }
}
