﻿using NsccApplication_DataLayer;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.OData;
using System.Web.OData.Routing;

namespace NsccApplicantODATAService.Controllers
{
    public class ProgramChoicesController:ODataController
    {
        NsccApplicationContext db = new NsccApplicationContext();

        [ODataRoute]
        private bool CourseExists(int key1, int key2)
        {
            return db.ProgramChoices.Any(p => p.CampusId == key1 && p.ProgramId==key2);
        }
        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }

        //CRUD
        //GET
        [EnableQuery]
        public IQueryable<ProgramChoice> Get()
        {
            return db.ProgramChoices;
        }
        [EnableQuery]
        //[ODataRoute("ProgramChoices(CampusId={key1},ProgramId={key2})")]
        public SingleResult<ProgramChoice> Get([FromODataUri] int key1 , [FromODataUri] int key2)
        {
            IQueryable<ProgramChoice> result = db.ProgramChoices.Where(p => p.CampusId == key1 && p.ProgramId == key2);
            return SingleResult.Create(result);
        }

        //POST
        public async Task<IHttpActionResult> Post(ProgramChoice pc)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            db.ProgramChoices.Add(pc);
            await db.SaveChangesAsync();
            return Created(pc);
        }

        //UPDATE
        //[ODataRoute("ProgramChoices(CampusId={key1},ProgramId={key2})")]
        public async Task<IHttpActionResult> Patch([FromODataUri] int key1, [FromODataUri] int key2, Delta<ProgramChoice> programChoice)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var entity = await db.ProgramChoices.FindAsync(key1,key2);
            if (entity == null)
            {
                return NotFound();
            }
            programChoice.Patch(entity);
            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CourseExists(key1,key2))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return Updated(entity);
        }

        //DELETE
        //[ODataRoute("ProgramChoices(CampusId={key1},ProgramId={key2})")]
        public async Task<IHttpActionResult> Delete([FromODataUri] int key1, [FromODataUri] int key2)
        {
            var programChoice = await db.ProgramChoices.FindAsync(key1,key2);
            if (programChoice == null)
            {
                return NotFound();
            }
            db.ProgramChoices.Remove(programChoice);
            await db.SaveChangesAsync();
            return StatusCode(HttpStatusCode.NoContent);
        }
    }
}