﻿using NsccApplication_DataLayer;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.OData;

namespace NsccApplicantODATAService.Controllers
{
    public class CitizenshipsController:ODataController
    {
        NsccApplicationContext db = new NsccApplicationContext();
        private bool CourseExists(int key)
        {
            return db.Citizenships.Any(p => p.CitizenshipId == key);
        }
        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }

        //CRUD
        //GET
        [EnableQuery]
        public IQueryable<Citizenship> Get()
        {
            return db.Citizenships;
        }
        [EnableQuery]
        public SingleResult<Citizenship> Get([FromODataUri] int key)
        {
            IQueryable<Citizenship> result = db.Citizenships.Where(p => p.CitizenshipId == key);
            return SingleResult.Create(result);
        }

        //POST
        public async Task<IHttpActionResult> Post(Citizenship citizenship)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            db.Citizenships.Add(citizenship);
            await db.SaveChangesAsync();
            return Created(citizenship);
        }

        //UPDATE

        public async Task<IHttpActionResult> Patch([FromODataUri] int key, Delta<Citizenship> citizenships)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var entity = await db.Citizenships.FindAsync(key);
            if (entity == null)
            {
                return NotFound();
            }
            citizenships.Patch(entity);
            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CourseExists(key))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return Updated(entity);
        }

        //DELETE

        public async Task<IHttpActionResult> Delete([FromODataUri] int key)
        {
            var citizenship = await db.Citizenships.FindAsync(key);
            if (citizenship == null)
            {
                return NotFound();
            }
            db.Citizenships.Remove(citizenship);
            await db.SaveChangesAsync();
            return StatusCode(HttpStatusCode.NoContent);
        }
    }
}