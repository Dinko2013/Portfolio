﻿using NsccApplication_DataLayer;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.OData;


namespace NsccApplicantODATAService.Controllers
{
    public class CountriesController:ODataController
    {
        NsccApplicationContext db = new NsccApplicationContext();
        private bool CourseExists(string key)
        {
            return db.Countries.Any(p => p.CountryCode == key);
        }
        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }

        //CRUD
        //GET
        [EnableQuery]
        public IQueryable<Country> Get()
        {
            return db.Countries;
        }
        [EnableQuery]
        public SingleResult<Country> Get([FromODataUri] string key)
        {
            IQueryable<Country> result = db.Countries.Where(p => p.CountryCode == key);
            return SingleResult.Create(result);
        }

        //POST
        public async Task<IHttpActionResult> Post(Country country)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            db.Countries.Add(country);
            await db.SaveChangesAsync();
            return Created(country);
        }

        //UPDATE

        public async Task<IHttpActionResult> Patch([FromODataUri] string key, Delta<Country> country)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var entity = await db.Countries.FindAsync(key);
            if (entity == null)
            {
                return NotFound();
            }
            country.Patch(entity);
            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CourseExists(key))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return Updated(entity);
        }

        //DELETE

        public async Task<IHttpActionResult> Delete([FromODataUri] string key)
        {
            var country = await db.Countries.FindAsync(key);
            if (country == null)
            {
                return NotFound();
            }
            db.Countries.Remove(country);
            await db.SaveChangesAsync();
            return StatusCode(HttpStatusCode.NoContent);
        }
    }
}