﻿using NsccApplication_DataLayer;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.OData;
using System.Web.OData.Routing;

namespace NsccApplicantODATAService.Controllers
{
    public class ProvinceStatesController : ODataController
    {
        NsccApplicationContext db = new NsccApplicationContext();

        [ODataRoute]
        private bool CourseExists(string key1, string key2)
        {
            return db.ProvinceStates.Any(p => p.ProvinceStateCode == key1 && p.CountryCode == key2);
        }
        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }

        //CRUD
        //GET
        [EnableQuery]
        public IQueryable<ProvinceState> Get()
        {
            return db.ProvinceStates;
        }
        [EnableQuery]
        [ODataRoute("ProvinceStates(ProvinceStateCode={key1},CountryCode={key2})")]
        public SingleResult<ProvinceState> Get([FromODataUri] string key1, [FromODataUri] string key2)
        {
            IQueryable<ProvinceState> result = db.ProvinceStates.Where(p => p.ProvinceStateCode == key1 && p.CountryCode== key2);

            return SingleResult.Create(result);
        }

        //POST
        public async Task<IHttpActionResult> Post(ProvinceState ps)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            db.ProvinceStates.Add(ps);
            await db.SaveChangesAsync();
            return Created(ps);
        }

        //UPDATE
        [ODataRoute("ProvinceStates(ProvinceStateCode={key1},CountryCode={key2})")]
        public async Task<IHttpActionResult> Patch([FromODataUri] string key1, [FromODataUri] string key2, Delta<ProvinceState> provinceState)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var entity = await db.ProvinceStates.FindAsync(key1,key2);
            if (entity == null)
            {
                return NotFound();
            }
            provinceState.Patch(entity);
            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CourseExists(key1,key2))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return Updated(entity);
        }

        //DELETE
        [ODataRoute("ProvinceStates(ProvinceStateCode={key1},CountryCode={key2})")]
        public async Task<IHttpActionResult> Delete([FromODataUri] string key1, [FromODataUri] string key2)
        {
            var provinceState = await db.ProvinceStates.FindAsync(key1,key2);
            if (provinceState == null)
            {
                return NotFound();
            }
            db.ProvinceStates.Remove(provinceState);
            await db.SaveChangesAsync();
            return StatusCode(HttpStatusCode.NoContent);
        }
    }
}