﻿using NsccApplication_DataLayer;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.OData;

namespace NsccApplicantODATAService.Controllers
{
    public class ApplicantsController:ODataController
    {
        NsccApplicationContext db = new NsccApplicationContext();
        private bool CourseExists(int key)
        {
            return db.Applicants.Any(p => p.ApplicantId == key);
        }
        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }

        //CRUD
        //GET
        [EnableQuery]
        public IQueryable<Applicant> Get()
        {
            return db.Applicants;
        }
        [EnableQuery]
        public SingleResult<Applicant> Get([FromODataUri] int key)
        {
            IQueryable<Applicant> result = db.Applicants.Where(p => p.ApplicantId == key);
            return SingleResult.Create(result);
        }

        //POST
        public async Task<IHttpActionResult> Post(Applicant applicants)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            db.Applicants.Add(applicants);
            await db.SaveChangesAsync();
            return Created(applicants);
        }

        //UPDATE

        public async Task<IHttpActionResult> Patch([FromODataUri] int key, Delta<Applicant> applicants)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var entity = await db.Applicants.FindAsync(key);
            if (entity == null)
            {
                return NotFound();
            }
            applicants.Patch(entity);
            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CourseExists(key))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return Updated(entity);
        }

        //DELETE

        public async Task<IHttpActionResult> Delete([FromODataUri] int key)
        {
            var applicant = await db.Applicants.FindAsync(key);
            if (applicant == null)
            {
                return NotFound();
            }
            db.Applicants.Remove(applicant);
            await db.SaveChangesAsync();
            return StatusCode(HttpStatusCode.NoContent);
        }
    }
}