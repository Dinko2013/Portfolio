﻿using NsccApplication_DataLayer;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.OData;
using System.Web.OData.Routing;

namespace NsccApplicantODATAService.Controllers
{
    public class CampusesController:ODataController
    {
        NsccApplicationContext db = new NsccApplicationContext();
        private bool CourseExists(int key)
        {
            return db.Campuses.Any(p => p.CampusId == key);
        }
        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }

        //CRUD
        //GET
        [EnableQuery]
        public IQueryable<Campus> Get()
        {
            return db.Campuses;
        }
        [EnableQuery]
        public SingleResult<Campus> Get([FromODataUri] int key)
        {
            IQueryable<Campus> result = db.Campuses.Where(p => p.CampusId == key);
            return SingleResult.Create(result);
        }

        //POST
        public async Task<IHttpActionResult> Post(Campus campus)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            db.Campuses.Add(campus);
            await db.SaveChangesAsync();
            return Created(campus);
        }

        //UPDATE

        public async Task<IHttpActionResult> Patch([FromODataUri] int key, Delta<Campus> campuses)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var entity = await db.Campuses.FindAsync(key);
            if (entity == null)
            {
                return NotFound();
            }
            campuses.Patch(entity);
            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CourseExists(key))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return Updated(entity);
        }

        //DELETE

        public async Task<IHttpActionResult> Delete([FromODataUri] int key)
        {
            var campus = await db.Campuses.FindAsync(key);
            if (campus == null)
            {
                return NotFound();
            }
            db.Campuses.Remove(campus);
            await db.SaveChangesAsync();
            return StatusCode(HttpStatusCode.NoContent);
        }
        [EnableQuery]
        [ODataRoute("Campuses(CampusId={key})/Programs")]
        public ICollection<Program> GetCampusPrograms([FromODataUri] int key)
        {

            Campus campus = db.Campuses.Find(key);
            return campus.Programs;
        }

    }
}
