﻿using NsccApplication_DataLayer;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.OData;
namespace NsccApplicantODATAService.Controllers
{
    public class AcademicYearsController:ODataController
    {
        NsccApplicationContext db = new NsccApplicationContext();
        private bool CourseExists(int key)
        {
            return db.AcademicYears.Any(p => p.AcademicYearId == key);
        }
        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }

        //CRUD
        //GET
        [EnableQuery]
        public IQueryable<AcademicYear> Get()
        {
            return db.AcademicYears;
        }
        [EnableQuery]
        public SingleResult<AcademicYear> Get([FromODataUri] int key)
        {
            IQueryable<AcademicYear> result = db.AcademicYears.Where(p => p.AcademicYearId == key);
            return SingleResult.Create(result);
        }

        //POST
        public async Task<IHttpActionResult> Post(AcademicYear ay)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            db.AcademicYears.Add(ay);
            await db.SaveChangesAsync();
            return Created(ay);
        }

        //UPDATE

        public async Task<IHttpActionResult> Patch([FromODataUri] int key, Delta<AcademicYear> acedemicYear)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var entity = await db.AcademicYears.FindAsync(key);
            if (entity == null)
            {
                return NotFound();
            }
            acedemicYear.Patch(entity);
            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CourseExists(key))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return Updated(entity);
        }

        //DELETE

        public async Task<IHttpActionResult> Delete([FromODataUri] int key)
        {
            var acedemicYear = await db.AcademicYears.FindAsync(key);
            if (acedemicYear == null)
            {
                return NotFound();
            }
            db.AcademicYears.Remove(acedemicYear);
            await db.SaveChangesAsync();
            return StatusCode(HttpStatusCode.NoContent);
        }
    }
}