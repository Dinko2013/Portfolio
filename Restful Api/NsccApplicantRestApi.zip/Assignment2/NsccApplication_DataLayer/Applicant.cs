﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NsccApplication_DataLayer
{
    public class Applicant
    {
        [Key]
        public int ApplicantId { get; set; }

        [StringLength(10)]
        public string SIN { get; set; }

        [StringLength(10)]
        public string Prefix { get; set; }

        [Required]
        [StringLength(50)]
        public string FirstName { get; set; }

        [Required]
        [StringLength(50)]
        public string MiddleName { get; set; }

        [Required]
        [StringLength(50)]
        public string LastName { get; set; }

        [StringLength(50)]
        public string FirtNamePreferred { get; set; }

        [StringLength(50)]
        public string LastNamePreferred { get; set; }

        public DateTime DOB { get; set; }

        [Required]
        [StringLength(1)]
        public string Gender { get; set; }

        [Required]
        [StringLength(50)]
        public string StreetAddress1 { get; set; }

        [StringLength(50)]
        public string StreetAddress2 { get; set; }

        [Required]
        [StringLength(50)]
        public string City { get; set; }

        [StringLength(50)]
        public string Country { get; set; }

        [StringLength(2)]
        public string ProvinceStateCode { get; set; }

        [StringLength(50)]
        public string ProvinvceStateOther { get; set; }

        [Required]
        [StringLength(2)]
        [ForeignKey("Countries")]
        public string CountryCode { get; set; }

        [Required]
        [StringLength(25)]
        public string PhoneHome { get; set; }

        [StringLength(25)]
        public string PhoneWork { get; set; }

        [StringLength(25)]
        public string PhoneCell { get; set; }

        [Required]
        [StringLength(50)]
        public string Email { get; set; }

        public int Citizenship { get; set; }

        [StringLength(2)]
        public string CitizenshipOther { get; set; }

        [Required]
        [StringLength(50)]
        public string password { get; set; }

        public bool HasCriminalConviction { get; set; }

        public bool HasChildAbuseRegistry { get; set; }

        public bool HasDiscipilinaryAction { get; set; }

        public bool IsAfricanCanadian { get; set; }

        public bool IsFirstNation { get; set; }

        public bool IsCurrentALP { get; set; }

        public bool HasDisability { get; set; }

        public virtual List<Application> Applications { get; set; }
        [ForeignKey("ProvinceStateCode, CountryCode")]
        public virtual ProvinceState ProvinceStates { get; set; }
        [ForeignKey("CitizenshipOther")]
        public virtual Country Countries { get; set; }
        [ForeignKey("Citizenship")]
        public virtual Citizenship Citizens { get; set; }

    }
}
