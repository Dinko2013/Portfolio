﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NsccApplication_DataLayer
{
    public class Campus
    {

        [Key]
        public int CampusId { get; set; }

        [Required]
        [StringLength(300)]
        public string Name { get; set; }

        public virtual List<Program> Programs { get; set; }
        public virtual List<ProgramChoice> ProgramChoices { get; set; }
    }
}
