﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NsccApplication_DataLayer
{
    public class ProgramChoice
    {
        [Key][Required]
        public int ProgramChoiceId { get; set; }

        [Required]
        public int ApplicationId { get; set; }

        [Required]
        public int CampusId { get; set; }

        [Required]
        public int ProgramId { get; set; }

        [Required]
        public int Preference { get; set; }


        public virtual List<Application> Application { get; set; }
        public virtual List <Campus> Campus { get; set; }
        public virtual List<Program> Program { get; set; }
    }
}
