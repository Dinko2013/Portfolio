USE [NsccApplicants]
GO

INSERT INTO [dbo].[AcademicYears]([Description])VALUES('Fall 2013/Winter 2014')
INSERT INTO [dbo].[AcademicYears]([Description])VALUES('Fall 2014/Winter 2015')
INSERT INTO [dbo].[AcademicYears]([Description])VALUES('Fall 2015/Winter 2016')
INSERT INTO [dbo].[AcademicYears]([Description])VALUES('Fall 2016/Winter 2017')
INSERT INTO [dbo].[AcademicYears]([Description])VALUES('Fall 2017/Winter 2018')
GO

INSERT INTO [dbo].[Campus]([Name])VALUES('Akerley Campus'),
										('Annapolis Valley Campus'),
										('Burridge Campus'),
										('Cumberland Campus'),
										('Institute of Technology Campus'),
										('Kingstec Campus'),
										('Lunenburg Campus'),
										('Marconi Campus'),
										('Pictou Campus'),
										('Shelburne Campus'),
										('Strait Area Campus'),
										('Truro Campus'),
										('Waterfront Campus'),
										('Aviation Institute'),
										('Centre of Geographic Sciences (COGS)'),
										('Nautical Institute & School of Fisheries')

GO


INSERT INTO [dbo].[Citizenships]([Description])VALUES('Canadian citizen'),
													 ('New Canadian/permanent resident'),
													 ('Refugee with protected person status'),
													 ('Other')
												
GO

INSERT INTO [dbo].[Countries]([CountryCode],[CountryName])VALUES('AD', 'Andorra'),
		('AF', 'Afghanistan'),
		('AG', 'Antigua and Barbuda'),
		('AI', 'Anguilla'),
		('AL', 'Albania'),
		('AM', 'Armenia'),
		('AO', 'Angola'),
		('AQ', 'Antarctica'),
		('AR', 'Argentina'),
		('AS', 'American Samoa'),
		('AT', 'Austria'),
		('AU', 'Australia'),
		('AW', 'Aruba'),
		('AX', 'Åland'),
		('AZ', 'Azerbaijan'),
		('BA', 'Bosnia and Herzegovina'),
		('BB', 'Barbados'),
		('BD', 'Bangladesh'),
		('BE', 'Belgium'),
		('BF', 'Burkina Faso'),
		('BG', 'Bulgaria'),
		('BH', 'Bahrain'),
		('BI', 'Burundi'),
		('BJ', 'Benin'),
		('BL', 'Saint Barthélemy'),
		('BM', 'Bermuda'),
		('BN', 'Brunei'),
		('BO', 'Bolivia'),
		('BQ', 'Bonaire'),
		('BR', 'Brazil'),
		('BS', 'Bahamas'),
		('BT', 'Bhutan'),
		('BV', 'Bouvet Island'),
		('BW', 'Botswana'),
		('BY', 'Belarus'),
		('BZ', 'Belize'),
		('CC', 'Cocos [Keeling] Islands'),
		('CD', 'Democratic Republic of the Congo'),
		('CF', 'Central African Republic'),
		('CG', 'Republic of the Congo'),
		('CH', 'Switzerland'),
		('CI', 'Ivory Coast'),
		('CK', 'Cook Islands'),
		('CL', 'Chile'),
		('CM', 'Cameroon'),
		('CN', 'China'),
		('CO', 'Colombia'),
		('CR', 'Costa Rica'),
		('CU', 'Cuba'),
		('CV', 'Cape Verde'),
		('CW', 'Curacao'),
		('CX', 'Christmas Island'),
		('CY', 'Cyprus'),
		('CZ', 'Czech Republic'),
		('DE', 'Germany'),
		('DJ', 'Djibouti'),
		('DK', 'Denmark'),
		('DM', 'Dominica'),
		('DO', 'Dominican Republic'),
		('DZ', 'Algeria'),
		('EC', 'Ecuador'),
		('EE', 'Estonia'),
		('EG', 'Egypt'),
		('EH', 'Western Sahara'),
		('ER', 'Eritrea'),
		('ES', 'Spain'),
		('ET', 'Ethiopia'),
		('FI', 'Finland'),
		('FJ', 'Fiji'),
		('FK', 'Falkland Islands'),
		('FM', 'Micronesia'),
		('FO', 'Faroe Islands'),
		('FR', 'France'),
		('GA', 'Gabon'),
		('GB', 'United Kingdom'),
		('GD', 'Grenada'),
		('GE', 'Georgia'),
		('GF', 'French Guiana'),
		('GG', 'Guernsey'),
		('GH', 'Ghana'),
		('GI', 'Gibraltar'),
		('GL', 'Greenland'),
		('GM', 'Gambia'),
		('GN', 'Guinea'),
		('GP', 'Guadeloupe'),
		('GQ', 'Equatorial Guinea'),
		('GR', 'Greece'),
		('GS', 'South Georgia and the South Sandwich Islands'),
		('GT', 'Guatemala'),
		('GU', 'Guam'),
		('GW', 'Guinea-Bissau'),
		('GY', 'Guyana'),
		('HK', 'Hong Kong'),
		('HM', 'Heard Island and McDonald Islands'),
		('HN', 'Honduras'),
		('HR', 'Croatia'),
		('HT', 'Haiti'),
		('HU', 'Hungary'),
		('ID', 'Indonesia'),
		('IE', 'Ireland'),
		('IL', 'Israel'),
		('IM', 'Isle of Man'),
		('IN', 'India'),
		('IO', 'British Indian Ocean Territory'),
		('IQ', 'Iraq'),
		('IR', 'Iran'),
		('IS', 'Iceland'),
		('IT', 'Italy'),
		('JE', 'Jersey'),
		('JM', 'Jamaica'),
		('JO', 'Jordan'),
		('JP', 'Japan'),
		('KE', 'Kenya'),
		('KG', 'Kyrgyzstan'),
		('KH', 'Cambodia'),
		('KI', 'Kiribati'),
		('KM', 'Comoros'),
		('KN', 'Saint Kitts and Nevis'),
		('KP', 'North Korea'),
		('KR', 'South Korea'),
		('KW', 'Kuwait'),
		('KY', 'Cayman Islands'),
		('KZ', 'Kazakhstan'),
		('LA', 'Laos'),
		('LB', 'Lebanon'),
		('LC', 'Saint Lucia'),
		('LI', 'Liechtenstein'),
		('LK', 'Sri Lanka'),
		('LR', 'Liberia'),
		('LS', 'Lesotho'),
		('LT', 'Lithuania'),
		('LU', 'Luxembourg'),
		('LV', 'Latvia'),
		('LY', 'Libya'),
		('MA', 'Morocco'),
		('MC', 'Monaco'),
		('MD', 'Moldova'),
		('ME', 'Montenegro'),
		('MF', 'Saint Martin'),
		('MG', 'Madagascar'),
		('MH', 'Marshall Islands'),
		('MK', 'Macedonia'),
		('ML', 'Mali'),
		('MM', 'Myanmar [Burma]'),
		('MN', 'Mongolia'),
		('MO', 'Macao'),
		('MP', 'Northern Mariana Islands'),
		('MQ', 'Martinique'),
		('MR', 'Mauritania'),
		('MS', 'Montserrat'),
		('MT', 'Malta'),
		('MU', 'Mauritius'),
		('MV', 'Maldives'),
		('MW', 'Malawi'),
		('MX', 'Mexico'),
		('MY', 'Malaysia'),
		('MZ', 'Mozambique'),
		('NA', 'Namibia'),
		('NC', 'New Caledonia'),
		('NE', 'Niger'),
		('NF', 'Norfolk Island'),
		('NG', 'Nigeria'),
		('NI', 'Nicaragua'),
		('NL', 'Netherlands'),
		('NO', 'Norway'),
		('NP', 'Nepal'),
		('NR', 'Nauru'),
		('NU', 'Niue'),
		('NZ', 'New Zealand'),
		('OM', 'Oman'),
		('PA', 'Panama'),
		('PE', 'Peru'),
		('PF', 'French Polynesia'),
		('PG', 'Papua New Guinea'),
		('PH', 'Philippines'),
		('PK', 'Pakistan'),
		('PL', 'Poland'),
		('PM', 'Saint Pierre and Miquelon'),
		('PN', 'Pitcairn Islands'),
		('PR', 'Puerto Rico'),
		('PS', 'Palestine'),
		('PT', 'Portugal'),
		('PW', 'Palau'),
		('PY', 'Paraguay'),
		('QA', 'Qatar'),
		('RE', 'Réunion'),
		('RO', 'Romania'),
		('RS', 'Serbia'),
		('RU', 'Russia'),
		('RW', 'Rwanda'),
		('SA', 'Saudi Arabia'),
		('SB', 'Solomon Islands'),
		('SC', 'Seychelles'),
		('SD', 'Sudan'),
		('SE', 'Sweden'),
		('SG', 'Singapore'),
		('SH', 'Saint Helena'),
		('SI', 'Slovenia'),
		('SJ', 'Svalbard and Jan Mayen'),
		('SK', 'Slovakia'),
		('SL', 'Sierra Leone'),
		('SM', 'San Marino'),
		('SN', 'Senegal'),
		('SO', 'Somalia'),
		('SR', 'Suriname'),
		('SS', 'South Sudan'),
		('ST', 'São Tomé and Príncipe'),
		('SV', 'El Salvador'),
		('SX', 'Sint Maarten'),
		('SY', 'Syria'),
		('SZ', 'Swaziland'),
		('TC', 'Turks and Caicos Islands'),
		('TD', 'Chad'),
		('TF', 'French Southern Territories'),
		('TG', 'Togo'),
		('TH', 'Thailand'),
		('TJ', 'Tajikistan'),
		('TK', 'Tokelau'),
		('TL', 'East Timor'),
		('TM', 'Turkmenistan'),
		('TN', 'Tunisia'),
		('TO', 'Tonga'),
		('TR', 'Turkey'),
		('TT', 'Trinidad and Tobago'),
		('TV', 'Tuvalu'),
		('TW', 'Taiwan'),
		('TZ', 'Tanzania'),
		('UA', 'Ukraine'),
		('AE', 'United Arab Emirates'),
		('UG', 'Uganda'),
		('UM', 'U.S. Minor Outlying Islands'),
		('UY', 'Uruguay'),
		('UZ', 'Uzbekistan'),
		('VA', 'Vatican City'),
		('VC', 'Saint Vincent and the Grenadines'),
		('VE', 'Venezuela'),
		('VG', 'British Virgin Islands'),
		('VI', 'U.S. Virgin Islands'),
		('VN', 'Vietnam'),
		('VU', 'Vanuatu'),
		('WF', 'Wallis and Futuna'),
		('WS', 'Samoa'),
		('XK', 'Kosovo'),
		('YE', 'Yemen'),
		('YT', 'Mayotte'),
		('ZA', 'South Africa'),
		('ZM', 'Zambia'),
		('ZW', 'Zimbabwe')
GO

INSERT INTO [dbo].[Countries]([CountryCode],[CountryName])VALUES('CA', 'Canada'), ('US', 'United States');
GO

INSERT INTO [dbo].[Programs]([Name])VALUES('Academic & Career Connections'),
('Addictions Community Outreach'),
('Adult Learning Program'),
('African Canadian Transition Program'),
('Aircraft Maintenance Engineer (Avionics)'),
('Aircraft Maintenance Engineer (Mechanical)'),
('Aircraft Maintenance Engineer (Structures)'),
('American Sign Language/English Interpretation'),
('Applied Media & Communication Arts'),
('Architectural Engineering Technician'),
('Automotive Collision Repair & Refinishing'),
('Automotive Service & Repair'),
('Automotive Service Advisor'),
('Baking & Pastry Art'),
('Behavioural Interventions'),
('Boulanger & Baking Art'),
('Bricklaying Masonry'),
('Building Systems Technician (HVAC&R)'),
('Business Administration'),
('Business Administration - Accounting Concentration'),
('Business Administration - Financial Services Concentration'),
('Business Administration - Investment Management Concentration'),
('Business Administration - Management Concentration'),
('Business Administration - Marketing Concentration'),
('Business Administration - Software & Information Management Concentration'),
('Cabinetmaking'),
('CAD Technician - Mechanical'),
('Carpentry'),
('Civil Engineering Technology'),
('Community Disability Supports'),
('Computer Electronics Technician'),
('Construction Management Technology'),
('Continuing Care'),
('Cooking'),
('Cosmetology'),
('Culinary Arts'),
('Deaf Studies'),
('Dental Assisting - Level II'),
('Diesel Repair – Industrial & Marine'),
('Digital Animation'),
('Drafting – Architectural'),
('Early Childhood Education'),
('Electrical - Construction & Industrial - Diploma'),
('Electrical - Construction & Industrial - Certificate'),
('Electrical Engineering Technology'),
('Electro Mechanical Technician'),
('Electronic Engineering Technician'),
('Electronic Engineering Technology'),
('Energy Sustainability Engineering Technology (ESET)'),
('English for Academic Purposes (EAP)'),
('Environmental Engineering Technology'),
('Esthetics'),
('Funeral & Allied Health Services'),
('Funeral Arranging & Directing'),
('Gas Technician'),
('Geographic Sciences'),
('Geographic Sciences - Cartography Concentration'),
('Geographic Sciences - Community & Environmental Planning Concentration'),
('Geographic Sciences - Geographic Information Systems (GIS) Concentration'),
('Geographic Sciences - Remote Sensing Technology Concentration'),
('Geographic Sciences – Advanced Diploma'),
('Geographic Sciences – Advanced Diploma - Geographic Information Systems (GIS) Concentratio'),
('Geographic Sciences – Advanced Diploma - GIS for Business Concentration'),
('Geographic Sciences – Advanced Diploma - Remote Sensing Concentration'),
('Geomatics Engineering Technology'),
('Graphic & Print Production'),
('Graphic Design'),
('Health Information Management (HIM)'),
('Heavy Duty Equipment /Truck and Transport Repair – Certificate'),
('Heavy Duty Equipment /Truck and Transport Repair – Diploma'),
('Heavy Equipment Operator'),
('Heritage Carpentry'),
('Horticulture & Landscape Technology'),
('Horticulture & Landscape Technology - Landscape Concentration'),
('Horticulture & Landscape Technology - Operations Concentration'),
('Human Resource Management'),
('Human Services'),
('Human Services - Child & Youth Care Concentration'),
('Human Services - Community Services Concentration'),
('Human Services - Correctional Services Concentration'),
('Human Services - Disability Supports & Services Concentration'),
('Human Services - Educational Support Concentration'),
('Human Services - Non-profit Leadership Concentration'),
('Human Services - Open Concentration'),
('Human Services - Therapeutic Recreation Concentration'),
('Industrial Engineering Technology'),
('Industrial Instrumentation'),
('Industrial Mechanical'),
('Information Technology (IT)'),
('Information Technology (IT) - Database Management Concentration'),
('Information Technology (IT) - Programming Concentration'),
('Information Technology (IT) - Systems Management/Networking Concentration'),
('Information Technology (IT) - Web Development Concentration'),
('Interactive & Motion Graphics'),
('Interactive & Motion Graphics - 3D Modeling & Motion Capture Concentration'),
('Interactive & Motion Graphics - Flash Interactive Media Concentration'),
('Interactive & Motion Graphics - Game Design Concentration'),
('Interactive & Motion Graphics - Visual Effects Concentration'),
('International Business'),
('Law & Security'),
('Library & Information Technology'),
('Machining'),
('Marine - Industrial Rigging'),
('Marine Engineering Technology'),
('Marine Geomatics'),
('Marine Navigation Technology'),
('Mechanical Engineering Technology'),
('Medical Laboratory Technology'),
('Medical Office Administration'),
('Medical Transcription'),
('Mental Health Recovery & Promotion'),
('Metal Fabrication'),
('Mi''kmaw Health & Wellness'),
('Motorcycle & Power Products Repair'),
('Music Arts'),
('Music Business'),
('Natural Resources Environmental Technology'),
('Occupational Health & Safety'),
('Occupational Therapy & Physiotherapy Assistant'),
('Office Administration'),
('Office Administration - Software & Information Management'),
('Oil Heat Systems Technician'),
('Paralegal Services'),
('Pharmacy Technology'),
('Photography'),
('Pipe Trades'),
('Plumbing'),
('Power Engineering Technology'),
('Practical Nursing'),
('Process Operations – 4th Class Power Engineering'),
('Public Relations'),
('Radio & Television Arts'),
('Radio & Television Arts - Broadcast Journalism Concentration'),
('Radio & Television Arts - Radio Performance & Studio Production Concentration'),
('Radio & Television Arts - Television Production Concentration'),
('Recording Arts'),
('Recreation Leadership'),
('Refrigeration & Air Conditioning'),
('Refrigeration & Air Conditioning - Geothermal'),
('Screen Arts'),
('Steamfitting/Pipefitting'),
('Survey Technician'),
('Tourism Management'),
('Utility Line Work-Construction & Maintenance'),
('Welding'),
('Welding – Certified'),
('Welding Inspection & Quality Control'),
('Wood Products Manufacturing Technology')
GO

INSERT INTO ProgramCampus (Program_ProgramId,Campus_CampusId) VALUES
('1','2')
,('1','3')
,('1','4')
,('1','5')
,('1','6')
,('1','8')
,('1','9')
,('1','11')
,('1','12')
,('1','13')
,('2','6')
,('3','1')
,('3','2')
,('3','3')
,('3','4')
,('3','5')
,('3','6')
,('3','7')
,('3','8')
,('3','9')
,('3','10')
,('3','11')
,('3','12')
,('4','14')
,('5','14')
,('6','14')
,('7','13')
,('8','2')
,('8','3')
,('8','8')
,('8','13')
,('9','13')
,('10','1')
,('11','1')
,('11','3')
,('11','6')
,('11','7')
,('11','8')
,('11','9')
,('12','1')
,('12','6')
,('13','2')
,('13','11')
,('14','1')
,('15','14')
,('16','13')
,('17','3')
,('17','4')
,('17','6')
,('17','7')
,('17','8')
,('17','9')
,('17','10')
,('17','11')
,('17','12')
,('17','13')
,('18','3')
,('18','4')
,('18','6')
,('18','7')
,('18','8')
,('18','9')
,('18','10')
,('18','11')
,('18','12')
,('18','13')
,('19','6')
,('19','13')
,('20','3')
,('20','4')
,('20','8')
,('20','13')
,('21','4')
,('21','6')
,('21','7')
,('21','9')
,('21','13')
,('22','3')
,('22','4')
,('22','6')
,('22','7')
,('22','8')
,('22','9')
,('22','10')
,('22','11')
,('22','12')
,('22','13')
,('23','3')
,('23','4')
,('23','6')
,('23','7')
,('23','11')
,('23','13')
,('24','9')
,('25','7')
,('26','13')
,('27','3')
,('27','4')
,('27','6')
,('27','8')
,('27','9')
,('27','11')
,('27','13')
,('28','12')
,('29','13')
,('30','7')
,('31','5')
,('32','13')
,('33','2')
,('33','3')
,('33','4')
,('33','6')
,('33','7')
,('33','8')
,('33','9')
,('33','10')
,('33','11')
,('33','12')
,('33','13')
,('34','9')
,('35','2')
,('35','3')
,('35','9')
,('35','11')
,('36','1')
,('36','6')
,('36','7')
,('36','8')
,('36','11')
,('37','13')
,('38','5')
,('39','7')
,('40','12')
,('41','7')
,('41','13')
,('42','4')
,('42','6')
,('42','3')
,('42','8')
,('43','4')
,('43','6')
,('43','7')
,('43','8')
,('43','10')
,('43','11')
,('43','13')
,('44','11')
,('45','13')
,('46','6')
,('47','9')
,('48','4')
,('48','6')
,('48','8')
,('48','9')
,('48','13')
,('49','13')
,('50','2')
,('51','5')
,('52','13')
,('53','2')
,('54','13')
,('57','1')
,('58','15')
,('59','15')
,('60','15')
,('61','15')
,('62','15')
,('63','15')
,('64','15')
,('65','15')
,('66','15')
,('67','15')
,('68','13')
,('69','8')
,('69','13')
,('69','2')
,('70','5')
,('71','8')
,('71','1')
,('72','1')
,('72','6')
,('72','9')
,('73','11')
,('74','7')
,('75','6')
,('76','6')
,('77','6')
,('78','8')
,('78','13')
,('80','12')
,('80','13')
,('81','3')
,('81','9')
,('82','12')
,('83','6')
,('83','8')
,('83','12')
,('84','6')
,('84','11')
,('85','8')
,('85','13')
,('86','13')
,('87','8')
,('88','5')
,('88','8')
,('89','2')
,('89','3')
,('89','5')
,('89','8')
,('89','12')
,('90','5')
,('91','5')
,('92','2')
,('92','5')
,('93','2')
,('93','3')
,('93','5')
,('93','8')
,('93','12')
,('94','3')
,('94','5')
,('94','8')
,('94','12')
,('95','12')
,('96','12')
,('97','12')
,('98','12')
,('99','12')
,('100','12')
,('101','13')
,('102','6')
,('102','9')
,('103','5')
,('104','11')
,('105','15')
,('106','11')
,('107','13')
,('108','13')
,('109','5')
,('109','6')
,('109','7')
,('109','8')
,('109','12')
,('110','5')
,('111','3')
,('112','1')
,('112','8')
,('113','8')
,('114','13')
,('115','13')
,('116','7')
,('116','11')
,('117','5')
,('117','8')
,('118','4')
,('119','10')
,('120','3')
,('120','4')
,('120','5')
,('120','6')
,('120','7')
,('120','8')
,('120','9')
,('120','10')
,('120','11')
,('120','12')
,('120','13')
,('121','3')
,('121','4')
,('121','6')
,('121','7')
,('121','11')
,('121','13')
,('122','13')
,('122','4')
,('123','13')
,('124','13')
,('125','5')
,('126','2')
,('126','6')
,('126','8')
,('126','9')
,('126','10')
,('126','11')
,('126','5')
,('127','1')
,('127','11')
,('128','7')
,('128','11')
,('128','3')
,('128','6')
,('128','8')
,('128','9')
,('128','12')
,('128','13')
,('128','4')
,('129','8')
,('130','8')
,('130','13')
,('131','13')
,('132','13')
,('133','13')
,('134','13')
,('135','13')
,('136','12')
,('137','7')
,('137','8')
,('138','4')
,('139','13')
,('140','1')
,('141','3')
,('141','4')
,('141','6')
,('141','8')
,('141','9')
,('141','11')
,('141','12')
,('141','13')
,('142','10')
,('142','11')
,('143','15')
,('144','13')
,('145','1')
,('145','6')
,('145','9')
,('146','1')
,('146','6')
,('147','1')
,('148','1')
,('148','6')
,('148','9');

GO


DECLARE @US_CountryCode varchar(2)
SET @US_CountryCode = 'US'
DECLARE @CAD_CountryCode varchar(2)
SET @CAD_CountryCode = 'CA'
INSERT INTO [dbo].[ProvinceStates] ([ProvinceStateCode],[CountryCode],[Name]) VALUES
 ('AK', @US_CountryCode ,'Alaska'),
 ('AL', @US_CountryCode ,'Alabama'),
 ('AS', @US_CountryCode ,'American Samoa'),
 ('AZ', @US_CountryCode ,'Arizona'),
 ('AR', @US_CountryCode ,'Arkansas'),
 ('CA', @US_CountryCode ,'California'),
 ('CO', @US_CountryCode ,'Colorado'),
 ('CT', @US_CountryCode ,'Connecticut'),
 ('DE', @US_CountryCode ,'Delaware'),
 ('DC', @US_CountryCode ,'District of Columbia'),
 ('FL', @US_CountryCode ,'Florida'),
 ('GA', @US_CountryCode ,'Georgia'), 
 ('GU',	@US_CountryCode ,'Guam'),
 ('HI', @US_CountryCode ,'Hawaii'),
 ('ID', @US_CountryCode ,'Idaho'),
 ('IL',	@US_CountryCode ,'Illinois'),
 ('IN', @US_CountryCode ,'Indiana'),
 ('IA',	@US_CountryCode ,'Iowa'),
 ('KS', @US_CountryCode ,'Kansas'),
 ('KY',	@US_CountryCode ,'Kentucky'),
 ('LA', @US_CountryCode ,'Louisiana'),
 ('ME', @US_CountryCode ,'Maine'),
 ('MD',	@US_CountryCode ,'Maryland'),
 ('MA', @US_CountryCode ,'Massachusetts'),
 ('MI',	@US_CountryCode ,'Michigan'),
 ('MN', @US_CountryCode ,'Minnesota'),
 ('MS', @US_CountryCode ,'Mississippi'),
 ('MO',	@US_CountryCode ,'Missouri'),
 ('MT', @US_CountryCode ,'Montana'),
 ('NE',	@US_CountryCode ,'Nebraska'),
 ('NV', @US_CountryCode ,'Nevada'),
 ('NH', @US_CountryCode ,'New Hampshire'),
 ('NJ', @US_CountryCode ,'New Jersey'),
 ('NM', @US_CountryCode ,'New Mexico'), 
 ('NY',	@US_CountryCode ,'New York'),
 ('NC', @US_CountryCode ,'North Carolina'),
 ('ND',	@US_CountryCode ,'North Dakota'),
 ('MP',	@US_CountryCode ,'Northern Mariana Islands'),
 ('OH',	@US_CountryCode ,'Ohio'),
 ('OK',	@US_CountryCode ,'Oklahoma'),
 ('OR', @US_CountryCode ,'Oregon'),
 ('PW', @US_CountryCode ,'Palau'), 
 ('PA',	@US_CountryCode ,'Pennsylvania'),
 ('PR', @US_CountryCode ,'Puerto Rico'),
 ('RI',	@US_CountryCode ,'Rhode Island'),
 ('SC', @US_CountryCode ,'South Carolina'),
 ('SD',	@US_CountryCode ,'South Dakota'),
 ('TN', @US_CountryCode ,'Tennessee'),
 ('TX', @US_CountryCode ,'Texas'), 
 ('UT',	@US_CountryCode ,'Utah'),
 ('VT', @US_CountryCode ,'Vermont'),
 ('VI', @US_CountryCode ,'Virgin Islands'),
 ('VA',	@US_CountryCode ,'Virginia'),
 ('WA', @US_CountryCode ,'Washington'),
 ('WV', @US_CountryCode ,'West Virginia'),
 ('WI', @US_CountryCode ,'Wisconsin'), 
 ('WY', @US_CountryCode ,'Wyoming'),
 ('AB', @CAD_CountryCode,'Alberta'),
 ('BC',	@CAD_CountryCode,'British Columbia'),
 ('MB',	@CAD_CountryCode,'Manitoba'),
 ('NB', @CAD_CountryCode,'New Brunswick'),
 ('NL', @CAD_CountryCode,'Newfoundland and Labrador'),
 ('NT',	@CAD_CountryCode,'Northwest Territories'),
 ('NS', @CAD_CountryCode,'Nova Scotia'),
 ('NU', @CAD_CountryCode,'Nunavut'),
 ('ON', @CAD_CountryCode,'Ontario'),
 ('PE', @CAD_CountryCode,'Prince Edward Island'),
 ('QC', @CAD_CountryCode,'Québec'),
 ('SK', @CAD_CountryCode,'Saskatchewan'),
 ('YT', @CAD_CountryCode,'Yukon Territory'); 

 GO