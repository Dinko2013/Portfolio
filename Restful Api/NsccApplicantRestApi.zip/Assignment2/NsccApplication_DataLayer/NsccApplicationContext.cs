﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NsccApplication_DataLayer
{
   public class NsccApplicationContext:DbContext
    {

        public NsccApplicationContext():base("NsccApplicants")
        {
            Database.SetInitializer(new DropCreateDatabaseIfModelChanges<NsccApplicationContext>());
        }
        public DbSet<Country> Countries { get; set; }
        public DbSet<Citizenship> Citizenships { get; set; }
        public DbSet<Program> Programs { get; set; }
        public DbSet<Campus> Campuses { get; set; }
        public DbSet<ProgramChoice> ProgramChoices { get; set; }
        public DbSet<ProvinceState> ProvinceStates { get; set; }
        public DbSet<AcademicYear> AcademicYears { get; set; }
        public DbSet<Application> Applications { get; set; }
        public DbSet<Applicant> Applicants { get; set; }




    }
}
