﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NsccApplication_DataLayer
{
    public class Country
    {
        [Key]
        [StringLength(2)]
        [Column (TypeName ="Char")]
        public string CountryCode { get; set; }

        [Required]
        [StringLength(200)]
        public string CountryName { get; set; }

        public virtual List<ProvinceState> ProvinceState { get; set; }

        [ForeignKey("CountryCode")]
        public virtual List<Applicant> Applicants { get; set; }

        [ForeignKey("CitizenshipOther")]
        public virtual List<Applicant> ApplicantCitizenShip { get; set; }
    }
}
