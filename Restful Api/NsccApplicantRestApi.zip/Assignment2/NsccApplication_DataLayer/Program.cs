﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NsccApplication_DataLayer
{
   public class Program
    {
        [Key]
        public int ProgramId { get; set; }

        [Required]
        [StringLength(350)]
        public string Name { get; set; }

        public virtual List<Campus> Campuses { get; set; }
        public virtual List<ProgramChoice> ProgramChoices { get; set; }
    }
}
