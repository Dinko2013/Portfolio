﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NsccApplication_DataLayer
{
   public class Application
    {
        [Key]
        public int ApplicationId { get; set; }
        [Required]
        public DateTime ApplicationDate { get; set; }

        [Required]
        [ForeignKey("Applicants")]
        public int ApplicantId { get; set; }

        public int ApplicationFee { get; set; }
        [Required]
        public char paid { get; set; }

        public virtual List<Applicant> Applicants { get; set; }
        public virtual List<ProgramChoice> ProgramChoices { get; set; }
        public virtual List<AcademicYear> AcademicYears { get; set; }
    }
}
