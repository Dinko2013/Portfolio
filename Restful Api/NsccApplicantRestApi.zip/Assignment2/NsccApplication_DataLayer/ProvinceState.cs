﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NsccApplication_DataLayer
{
    public class ProvinceState
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(2)]
        public string ProvinceStateCode { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(2)]
        public string CountryCode { get; set; }

        [Required]
        [StringLength(100)]
        public string Name { get; set; }

        [ForeignKey("CountryCode")]
        public virtual Country Country { get; set; }

        public virtual List<Applicant> Applicants { get; set; }
    }
}
